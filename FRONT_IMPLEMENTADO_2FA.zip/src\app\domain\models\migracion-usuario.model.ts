/**
 * @description
 * Clase modelo para los datos de migracion Cash del usuario.
 *
 * @property estadoMigracion {boolean} Indica si el usuario ha sido migrado a Cash.
 * @property fechaMigracion {string | null} Fecha en la que se realizo la migracion del usuario.
 * @property estado {number} Estado asociado al proceso de migracion.
 * @property identificacionPrincipal {string} Identificacion principal del usuario.
 * @property idUsuario {number} Identificador unico del usuario.
 */
export class MigracionUsuarioModel {
  estadoMigracion?: boolean;
  fechaMigracion?: string | null;
  estado?: number;
  identificacionPrincipal?: string;
  idUsuario?: number;
}