export const environment = {
  production: true,
  autenticacionStandalone: false,
  host: {
    port: '7151'
  },
  apiUrl: 'https://localhost:7053/',
  rutaCashManagement: 'https://cashmanagement.produbanco.com/cashmanagement/index.html',
  canal: 'IN'
};
