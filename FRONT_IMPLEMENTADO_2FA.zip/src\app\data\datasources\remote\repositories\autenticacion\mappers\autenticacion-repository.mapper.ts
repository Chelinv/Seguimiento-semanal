﻿
import { Mapper } from '@ngx-controlbase/core';
import { AutenticacionUsuarioModel } from 'src/app/domain/models';
import { AutenticacionUsuarioEntity } from '../entities/autenticacion-usuario.entity';

export class AutenticacionRepositoryMapper extends Mapper<
  AutenticacionUsuarioEntity,
  AutenticacionUsuarioModel
> {
  mapFrom(param: AutenticacionUsuarioEntity): AutenticacionUsuarioModel {
    return {
      title: param.usuario.titulo || param.usuario.title,
      description: param.usuario.descripcion || param.usuario.description,
      physicalDeliveryOfficeName: param.usuario.oficinaEntregaFisica || param.usuario.physicalDeliveryOfficeName,
      department: param.usuario.departamento || param.usuario.department,
      company: param.usuario.compania || param.usuario.company,
      streetAddress: param.usuario.direccion || param.usuario.streetAddress,
      name: (param.usuario.nombreCuentaSAM || param.usuario.sAMAccountName || '').toUpperCase(),
      username: param.usuario.nombreCuentaSAM || param.usuario.sAMAccountName,
      sAMAccountName: (param.usuario.nombreCuentaSAM || param.usuario.sAMAccountName || '').toUpperCase(),
      mail: param.usuario.correo || param.usuario.mail,
      cedula: param.usuario.cedula,
      token: param.tokenAcceso || param.access_token,
      tokenType: param.tipoToken || param.token_type,
      expiresIn: param.expiraEn || param.expires_in,
      manager: param.usuario.gerente || param.usuario.manager,
      msRTCSIPUserEnabled: param.usuario.usuarioSipHabilitado || param.usuario['msRTCSIP-UserEnabled'],
      msRTCSIPFederationEnabled: param.usuario.federacionSipHabilitada || param.usuario['msRTCSIP-FederationEnabled'],
      msRTCSIPInternetAccessEnabled: param.usuario.accesoInternetSipHabilitado || param.usuario['msRTCSIP-InternetAccessEnabled']
    };
  }
  mapTo(param: AutenticacionUsuarioModel): AutenticacionUsuarioEntity {
    return {
      usuario: {
        titulo: param.title!,
        title: param.title!,
        descripcion: param.description!,
        description: param.description!,
        oficinaEntregaFisica: param.physicalDeliveryOfficeName!,
        physicalDeliveryOfficeName: param.physicalDeliveryOfficeName!,
        departamento: param.department!,
        department: param.department!,
        compania: param.company!,
        company: param.company!,
        direccion: param.streetAddress!,
        streetAddress: param.streetAddress!,
        nombre: param.name!.toLowerCase(),
        name: param.name!.toLowerCase(),
        nombreCuentaSAM: param.sAMAccountName!.toLowerCase(),
        sAMAccountName: param.sAMAccountName!.toLowerCase(),
        correo: param.mail!,
        mail: param.mail!,
        gerente: param.manager!,
        manager: param.manager!,
        usuarioSipHabilitado: param.msRTCSIPUserEnabled!,
        'msRTCSIP-UserEnabled': param.msRTCSIPUserEnabled!,
        federacionSipHabilitada: param.msRTCSIPFederationEnabled!,
        'msRTCSIP-FederationEnabled': param.msRTCSIPFederationEnabled!,
        accesoInternetSipHabilitado: param.msRTCSIPInternetAccessEnabled!,
        'msRTCSIP-InternetAccessEnabled': param.msRTCSIPInternetAccessEnabled!,
        cedula: param.cedula!
      },
      tokenAcceso: param.token!,
      access_token: param.token!,
      tipoToken: param.tokenType!,
      token_type: param.tokenType!,
      expiraEn: param.expiresIn!,
      expires_in: param.expiresIn!
    };
  }
}
