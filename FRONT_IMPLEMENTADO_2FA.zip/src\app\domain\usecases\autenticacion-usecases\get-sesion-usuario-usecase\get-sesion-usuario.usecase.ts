import { Injectable } from '@angular/core';
import { NoParam, Usecase } from '@ngx-controlbase/core';
import { AutenticacionUsuarioModel } from '../../../models';
import { IAutenticacionRepository } from 'src/app/domain/repositories';

/**
 * @description
 * Clase para procesar el caso de uso de consultar de los datos del usuario autenticado
 */
@Injectable({ providedIn: 'root' })
export class GetSesionUsuarioUsecase implements Usecase<NoParam, AutenticacionUsuarioModel> {
  constructor(private readonly iAutenticacionRepository: IAutenticacionRepository) {}

  /**
   * @description
   * Funcion para consultar de los datos del usuario autenticado.
   * @return {AutenticacionUsuarioModel} Retorno de objeto con los datos del usuario.
   */
  execute(): AutenticacionUsuarioModel {
    return this.iAutenticacionRepository.getSesionUsuario;
  }
}
