/**
 * @description
 * Constantes globales.
 * @return {any} Retorna valor.
 */
export const TODO = 'All';
export const PARAMETRO_REQUERIDO = 'Parametro es requirido';
export const NUMERO_REGISTROS_TABLA_POR_DEFECTO = 25;
