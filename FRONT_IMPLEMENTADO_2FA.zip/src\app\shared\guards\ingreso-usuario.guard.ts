import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { LoginStateService } from '../services/login-state.service';

/**
 * @description
 * Guard encargado de validar que el usuario haya ingresado previamente
 * su nombre de usuario antes de acceder al paso de ingreso de clave.
 * Redirecciona al flujo de ingreso de usuario cuando no existe
 * información almacenada en el estado de autenticación.
 */
export const ingresoUsuarioGuard: CanActivateFn = () => {
  const loginState = inject(LoginStateService);
  const router = inject(Router);

  const { username } = loginState.currentState;
  if (username && username.trim() !== '') {
    return true;
  }

  return router.createUrlTree(['/authentication/ingreso-usuario']);
};
