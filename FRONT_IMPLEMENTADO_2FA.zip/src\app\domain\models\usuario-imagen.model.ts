/**
 * @description
 * Clase modelo para los datos de imagen de seguridad del usuario.
 *
 * @property imagenBase64 {string} Imagen de seguridad codificada en formato Base64.
 * @property perfilUsuario {boolean} Indica si la imagen corresponde al perfil del usuario.
 * @property factorBloqueo {number} Factor o nivel de bloqueo asociado al usuario.
 * @property codigo {string} Codigo de respuesta de la operacion.
 * @property mensaje {string} Mensaje descriptivo de la respuesta.
 * @property esExitoso {boolean} Indica si la operacion fue ejecutada exitosamente.
 */
export class UsuarioImagenModel {
  imagenBase64?: string;
  perfilUsuario?: boolean;
  factorBloqueo?: number;
  codigo?: string;
  mensaje?: string;
  esExitoso?: boolean;
}