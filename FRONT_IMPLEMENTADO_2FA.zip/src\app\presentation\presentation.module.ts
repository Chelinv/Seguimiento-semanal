﻿import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutModule } from '@angular/cdk/layout';
import { AuthenticationModule } from './authentication/authentication.module';
import { PresentationRoutingModule } from './presentation-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

/**
 * @description
 * Módulo encargado de agrupar los componentes, rutas y dependencias
 * de la capa de presentación de la aplicación.
 * Centraliza la configuración necesaria para la interacción con el usuario.
 */
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    PresentationRoutingModule,
    AuthenticationModule,
    LayoutModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PresentationModule {}