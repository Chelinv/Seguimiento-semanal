import { Result } from '@ngx-controlbase/core';
import { Observable } from 'rxjs';
import { AutenticacionUsuarioModel } from '../models';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export abstract class IAutenticacionRepository {
  /**
   * @description
   * Funcion para el login del usuario en la aplicacion.
   * @param username {string} Nombre del usuario.
   * @param password {string} Clave del usuario.
   * @return {Observable<AutenticacionUsuarioModel>} Retorna objeto con datos de respuesta del proceso.
   */
  abstract login(username: string, password: string): Observable<AutenticacionUsuarioModel>;

  /**
   * @description
   * Funcion para el cerrar las sesion del usuario en la aplicacion.
   * @return {Observable<Result>} Retorna objeto con datos de respuesta del proceso.
   */
  abstract logout(): Observable<Result>;

  /**
   * @description
   * Funcion para consultar de los datos del usuario autenticado.
   * @return {AutenticacionUsuarioModel} Retorno de objeto con los datos del usuario.
   */
  abstract get getSesionUsuario(): AutenticacionUsuarioModel;

  /**
   * @description
   * Funcion para consultar si el usuario tiene configurada una imagen de seguridad.
   * @param username {string} Nombre del usuario.
   * @return {Observable<Result>} Retorna objeto con datos de respuesta (imagen Base64).
   */
  abstract validarUsuarioImagen(username: string): Observable<Result>;

}
