﻿export { IAutenticacionRepository } from './iautenticacion.repository';
