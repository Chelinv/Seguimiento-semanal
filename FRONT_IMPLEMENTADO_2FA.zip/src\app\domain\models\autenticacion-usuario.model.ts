﻿/**
 * @description
 * Clase modelo para los datos del usuario.
 *
 * @property title {string} Titulo del usuario.
 * @property description {string} Descripcion del usuario.
 * @property physicalDeliveryOfficeName {string} Nombre de la oficina de entrega fisica.
 * @property department {string} Departamento del usuario.
 * @property company {string} CompaAia del usuario.
 * @property streetAddress {string} Direccion del usuario.
 * @property name {string} Nombre del usuario.
 * @property sAMAccountName {string} Nombre de cuenta SAM del usuario.
 * @property mail {string} Correo electronico del usuario.
 * @property manager {string} Gerente del usuario.
 * @property msRTCSIPUserEnabled {string} Indica si el usuario tiene habilitado el SIP de RTC.
 * @property msRTCSIPFederationEnabled {string} Indica si el usuario tiene habilitada la federacion SIP de RTC.
 * @property msRTCSIPInternetAccessEnabled {string} Indica si el usuario tiene habilitado el acceso a Internet SIP de RTC.
 * @property username {string} Nombre de usuario.
 * @property password {string} ContraseAa del usuario.
 * @property cedula {string} Cedula del usuario.
 * @property token {string} Token de autenticacion.
 * @property tokenType {string} Tipo de token.
 * @property expiresIn {string} Tiempo de expiracion del token.
 */
export class AutenticacionUsuarioModel {
  title?: string;
  description?: string;
  physicalDeliveryOfficeName?: string;
  department?: string;
  company?: string;
  streetAddress?: string;
  name?: string;
  sAMAccountName?: string;
  mail?: string;
  manager?: string;
  msRTCSIPUserEnabled?: string;
  msRTCSIPFederationEnabled?: string;
  msRTCSIPInternetAccessEnabled?: string;
  username?: string;
  password?: string;
  cedula?: string;
  token?: string;
  tokenType?: string;
  expiresIn?: string;
}
