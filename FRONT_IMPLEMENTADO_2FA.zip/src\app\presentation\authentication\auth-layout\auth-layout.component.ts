import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

/**
 * @description
 * Componente de layout encargado de gestionar la estructura visual
 * del flujo de autenticación y renderizar el contenido de las rutas hijas.
 */
@Component({
  selector: 'pdn-auth-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, TranslateModule],
  templateUrl: './auth-layout.component.html',
  styleUrls: ['./auth-layout.component.scss']
})
export class AuthLayoutComponent {}