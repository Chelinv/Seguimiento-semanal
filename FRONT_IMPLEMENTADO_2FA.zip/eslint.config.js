// @ts-check
const eslint = require('@eslint/js');
const tseslint = require('typescript-eslint');
const angular = require('angular-eslint');

module.exports = tseslint.config(
  {
    files: ['**/*.ts'],
    extends: [
      eslint.configs.recommended,
      ...tseslint.configs.recommended,
      ...tseslint.configs.stylistic,
      ...angular.configs.tsRecommended
    ],
    processor: angular.processInlineTemplates,
    rules: {
      '@angular-eslint/directive-selector': [
        'error',
        {
          type: 'attribute',
          prefix: 'pdn',
          style: 'camelCase'
        }
      ],
      '@angular-eslint/component-selector': [
        'error',
        {
          type: 'element',
          prefix: 'pdn',
          style: 'kebab-case'
        }
      ],
      '@typescript-eslint/no-explicit-any': 'off',
      '@typescript-eslint/no-unused-expressions': 'off'
    }
  },
  {
    files: ['**/*.html'],
    extends: [...angular.configs.templateRecommended, ...angular.configs.templateAccessibility],
    rules: {
      '@angular-eslint/template/elements-content': [
        'error',
        {
          allowList: [
            'parentKey',
            'pButton',
            'pRipple',
            'pInputText',
            'pTemplate',
            'pSortableColumn',
            'p-radioButton',
            'p-dropdown',
            'p-inputNumber',
            'p-dialog',
            'p-sortIcon',
            'p-tableCheckbox',
            'p-toast',
            'p-toolbar',
            'p-fileUpload',
            'pInputTextarea'
          ]
        }
      ],
      '@angular-eslint/template/label-has-associated-control': 'off',
      '@angular-eslint/template/accessibility-label-has-associated-control': 'off'
    }
  }
);
