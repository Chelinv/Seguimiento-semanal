﻿import { Provider } from '@angular/core';
import { AUTENTICACION_IOC } from './autenticacion.ioc';

/**
 * @description
 * Arreglo de providers
 * @return {Provider[]} `Provider[]` Retorna arreglo de provider.
 */
export const DATA_IOC: Provider[] = [
  ...AUTENTICACION_IOC
];
