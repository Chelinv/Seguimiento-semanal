export { CONTENEDOR_SERVICE_MODULO_IOC } from './contenedor-service-modulo.ioc';
