export { AutenticacionInteractor } from './autenticacion.interactor';
