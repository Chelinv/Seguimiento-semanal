import { Injectable } from '@angular/core';
import { Usecase, Result, NoParam } from '@ngx-controlbase/core';
import { Observable } from 'rxjs';
import { IAutenticacionRepository } from 'src/app/domain/repositories';

/**
 * @description
 * Clase para procesar el caso de uso de cierre de sesion del usuario
 */
@Injectable({ providedIn: 'root' })
export class LogoutAutenticacionUsecase implements Usecase<NoParam, Observable<Result>> {
  constructor(private readonly iAutenticacionRepository: IAutenticacionRepository) {}

  execute(): Observable<Result> {
    return this.iAutenticacionRepository.logout();
  }
}
