import { Injectable } from '@angular/core';
import { IAutenticacionInteractor, Param, Result } from '@ngx-controlbase/core';
import { Observable } from 'rxjs';
import { UserRequest } from '../../requests/user.request';

import { AutenticacionUsuarioModel } from 'src/app/domain/models';
import { LoginAutenticacionUsecase } from 'src/app/domain/usecases/autenticacion-usecases/login-usecase/login-autenticacion.usecase';
import { LogoutAutenticacionUsecase } from 'src/app/domain/usecases/autenticacion-usecases/logout-usecase/logout-autenticacion.usecase';
import { GetSesionUsuarioUsecase } from 'src/app/domain/usecases/autenticacion-usecases/get-sesion-usuario-usecase/get-sesion-usuario.usecase';

@Injectable({ providedIn: 'root' })
export class AutenticacionInteractor extends IAutenticacionInteractor {
  constructor(
    private readonly loginAutenticacionUsecase: LoginAutenticacionUsecase,
    private readonly logoutAutenticacionUsecase: LogoutAutenticacionUsecase,
    private readonly getSesionUsuarioUsecase: GetSesionUsuarioUsecase
  ) {
    super();
  }

  /**
   * @description
   * Funcion de autenticacion del usuario.
   * @param datos {UserRequest} Clave del usuario.
   * @return {Observable<AutenticacionUsuarioModel>} Retorna la respuesta del proceso.
   */
  public override login(datos: UserRequest): Observable<AutenticacionUsuarioModel> {
    return this.loginAutenticacionUsecase.execute(
      new Param({ ...datos, username: datos.username, password: datos.password })
    );
  }

  /**
   * @description
   * Funcion para el cierre de la sesion del usuario.
   * @return {Observable<Result>} Retorna la respuesta del proceso.
   */
  public override logout(): Observable<Result> {
    return this.logoutAutenticacionUsecase.execute();
  }

  /**
   * @description
   * Propiedad con los datos del usuario.
   * @return {AutenticacionUsuarioModel} Retorna la respuesta del proceso.
   */
  public override get getSesionUsuario(): AutenticacionUsuarioModel {
    return this.getSesionUsuarioUsecase.execute();
  }
}
