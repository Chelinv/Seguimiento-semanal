import { AutenticacionUsuarioModel } from '../../domain/models';

export class UserRequest extends AutenticacionUsuarioModel {}
