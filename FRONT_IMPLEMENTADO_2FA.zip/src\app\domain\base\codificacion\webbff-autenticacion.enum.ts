/**
 * @description
 * Constantes para el consumo de endpoints de FRK-WebBFF.Produnet.
 * Sigue el patron de codificacion utilizado en domain/base/codificacion.
 */
export const WEBBFF_AUTENTICACION_ENUM = {
  URL_IMAGEN_USUARIO: 'Autenticacion/Usuarios/{0}/Imagenes',
  URL_ESTADO_MIGRACION_CASH: 'Autenticacion/MigracionUsuarios/{0}',
  URL_ESTADO_DOBLE_FACTOR: 'Autenticacion/FactoresSeguridad/Estado',
  URL_DOBLE_FACTOR: 'Autenticacion/FactoresSeguridad/{0}'
} as const;

/**
 * @description
 * Nombres y valores por defecto para cabeceras HTTP requeridas por el WebBFF y Core.Autenticacion.
 */
export const CABECERAS_WEBBFF_ENUM = {
  NOMBRES: {
    CANAL: 'Canal',
    ID_SESSION: 'Convivencia-IdSession'
  },
  VALORES_DEFECTO: {
    CANAL: 'IN'
  }
} as const;
