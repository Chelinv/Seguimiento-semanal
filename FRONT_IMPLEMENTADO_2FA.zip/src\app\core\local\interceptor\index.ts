export { CONTENEDOR_INTERCEPTOR_MODULO_IOC } from './contenedor-interceptor-modulo.ioc';
