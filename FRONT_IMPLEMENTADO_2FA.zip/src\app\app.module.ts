import {
  CUSTOM_ELEMENTS_SCHEMA,
  importProvidersFrom,
  NgModule,
  provideZoneChangeDetection
} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpClient, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { provideAnimations } from '@angular/platform-browser/animations';
import { LoadingBarRouterModule, provideLoadingBarRouter } from '@ngx-loading-bar/router';
import {
  LoadingBarHttpClientModule,
  provideLoadingBarInterceptor
} from '@ngx-loading-bar/http-client';
import { LoadingBarModule } from '@ngx-loading-bar/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { PrimeNgImportModule, SpinnerDialogComponent } from '@ngx-controlbase/core';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { CONTENEDOR_INTERCEPTOR_MODULO_IOC } from './core/local/interceptor';
import { CONTENEDOR_SERVICE_MODULO_IOC } from './core/local/service';
import { DATA_IOC } from './data/dataioc';
import { environment } from 'src/environments/environment';
import { CoreModule } from './core/core.module';

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LoadingBarRouterModule,
    LoadingBarHttpClientModule,
    LoadingBarModule,
    CommonModule,
    FormsModule,
    SpinnerDialogComponent
  ],
  providers: [
    { provide: LocationStrategy, useClass: PathLocationStrategy },
    provideZoneChangeDetection({ eventCoalescing: true }),
    importProvidersFrom(
      PrimeNgImportModule,
      CommonModule,
      CoreModule,
      FormsModule,
      LoadingBarRouterModule,
      LoadingBarHttpClientModule,
      LoadingBarModule,
      LoggerModule.forRoot({
        serverLoggingUrl: `${environment.apiUrl}logs`,
        level: NgxLoggerLevel.TRACE,
        serverLogLevel: NgxLoggerLevel.ERROR,
        disableConsoleLogging: false
      }),
      TranslateModule.forRoot({
        loader: {
          deps: [HttpClient],
          provide: TranslateLoader,
          useFactory: createTranslateLoader
        }
      })
    ),
    provideAnimations(),
    provideHttpClient(withInterceptorsFromDi()),
    provideLoadingBarInterceptor(),
    provideLoadingBarRouter(),
    ...DATA_IOC,
    ...CONTENEDOR_INTERCEPTOR_MODULO_IOC,
    ...CONTENEDOR_SERVICE_MODULO_IOC
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {}
