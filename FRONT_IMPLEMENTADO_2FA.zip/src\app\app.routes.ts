import { Routes } from '@angular/router';


export const routes: Routes = [
  {
    path: '',
    redirectTo: 'authentication/ingreso-usuario',
    pathMatch: 'full'
  },
  {
    path: 'authentication',
    loadChildren: () =>
      import('./presentation/authentication/authentication.module').then(
        m => m.AuthenticationModule
      )
  }
];
