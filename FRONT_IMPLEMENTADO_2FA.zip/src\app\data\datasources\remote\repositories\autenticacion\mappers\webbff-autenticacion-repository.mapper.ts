import { Mapper } from '@ngx-controlbase/core';
import { ImagenUsuarioModeloEntity, UsuarioMigracionModeloEntity, RespuestaDtoEntity } from '../entities/webbff-autenticacion.entity';
import { UsuarioImagenModel } from 'src/app/domain/models/usuario-imagen.model';
import { MigracionUsuarioModel } from 'src/app/domain/models/migracion-usuario.model';

/**
 * @description
 * Mapea la respuesta del BFF hacia el modelo de dominio UsuarioImagenModel.
 */
export class UsuarioImagenWebBffMapper extends Mapper<RespuestaDtoEntity<ImagenUsuarioModeloEntity>, UsuarioImagenModel> {
  mapFrom(param: any): UsuarioImagenModel {
    const data = param.datos ?? param.Datos ?? param.data ?? param.Data ?? param;

    const result = {
      perfilUsuario: data.perfilUsuario ?? data.PerfilUsuario ?? false,
      imagenBase64: data.guidImagen ?? data.GuidImagen ?? '',
      factorBloqueo: data.factorBloqueo ?? data.FactorBloqueo ?? 0,
      codigo: String(param.codigo ?? param.Codigo ?? ''),
      mensaje: param.mensaje ?? param.Mensaje ?? '',
      esExitoso: param.esExitoso ?? param.EsExitoso ?? true
    };
    return result;
  }

  mapTo(param: UsuarioImagenModel): RespuestaDtoEntity<ImagenUsuarioModeloEntity> {
    return {
      codigo: param.codigo ? Number.parseInt(param.codigo, 10) : 0,
      mensaje: param.mensaje,
      esExitoso: param.esExitoso,
      datos: {
        perfilUsuario: param.perfilUsuario,
        factorBloqueo: param.factorBloqueo,
        guidImagen: param.imagenBase64
      } as unknown as ImagenUsuarioModeloEntity
    };
  }
}

/**
 * @description
 * Mapea el estado de migracion Cash desde WebBFF hacia el dominio.
 */
export class MigracionUsuarioWebBffMapper extends Mapper<RespuestaDtoEntity<UsuarioMigracionModeloEntity>, MigracionUsuarioModel> {
  mapFrom(param: any): MigracionUsuarioModel {
    const data = param.datos ?? param.Datos ?? param.data ?? param.Data ?? param;

    return {
      estadoMigracion: data.estadoMigracion ?? data.EstadoMigracion ?? false,
      fechaMigracion: data.fechaMigracion ?? data.FechaMigracion ?? null,
      estado: data.estado ?? data.Estado ?? 0,
      identificacionPrincipal: data.identificacionPrincipal ?? data.IdentificacionPrincipal ?? '',
      idUsuario: data.idUsuario ?? data.IdUsuario ?? 0
    };
  }

  mapTo(param: MigracionUsuarioModel): RespuestaDtoEntity<UsuarioMigracionModeloEntity> {
    return {
      datos: {
        estadoMigracion: param.estadoMigracion,
        fechaMigracion: param.fechaMigracion,
        estado: param.estado,
        identificacionPrincipal: param.identificacionPrincipal,
        idUsuario: param.idUsuario
      } as UsuarioMigracionModeloEntity
    };
  }
}
