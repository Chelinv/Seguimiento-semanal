import { Provider } from '@angular/core';
import { CONTENEDOR_HANDLER_IOC, CONTENEDOR_INTERCEPTOR_IOC } from '@ngx-controlbase/core';
import { ModuloAutorizadoInterceptor } from './implementation/modulo-autorizado.interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

/**
 * @description
 * Arreglo de provider de interceptores centralizado
 * @return {Provider[]} `Provider[]` Retorna arreglo de provider.
 */
export const CONTENEDOR_INTERCEPTOR_MODULO_IOC: Provider[] = [
  {
    provide: HTTP_INTERCEPTORS,
    useClass: ModuloAutorizadoInterceptor,
    multi: true
  },
  ...CONTENEDOR_INTERCEPTOR_IOC,
  ...CONTENEDOR_HANDLER_IOC
];
