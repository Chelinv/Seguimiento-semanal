﻿# FRK-Interoperabilidad.Identidad.Frontend

## Introducción
Este proyecto contiene la aplicación cliente (Frontend) construida en Angular para gestionar el flujo de autenticación, identidad y seguridad de los usuarios. Interactúa con los servicios de backend para validar credenciales, mostrar imágenes de seguridad y manejar el estado de las cuentas de usuario (como usuarios bloqueados o estados de migración).

## Instalación y Ejecución
Para configurar y correr el proyecto en un entorno local:

1. Asegúrate de tener instalado **Node.js** y **npm**.
2. Navega hasta esta carpeta en tu terminal.
3. Instala las dependencias necesarias:
   `ash
   npm install
   `
4. Ejecuta el servidor de desarrollo local:
   `ash
   npm start
   `
   *(Nota: Generalmente, este frontend se compila y ejecuta de manera integrada y es servido directamente por el proyecto monolito en .NET).*

## Construcción (Build) y Pruebas
Para compilar la aplicación para ambientes de producción u otros entornos, utiliza:
`ash
npm run build
`
Los archivos optimizados se generarán en la carpeta de distribución configurada.

## Contribución
Para mantener los estándares de desarrollo del banco:
- Respeta la arquitectura basada en componentes y el uso del sistema de diseño interno.
- Reutiliza las variables y enumerados globales (ej: codificacion.base) en lugar de quemar texto.
- Ejecuta las pruebas correspondientes y el linter antes de subir cambios (Pull Request).
