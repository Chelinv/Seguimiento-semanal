import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

/**
 * @description
 * Interface que representa el estado del proceso de autenticación.
 * Contiene la información necesaria para mantener el flujo de inicio de sesión.
 */
export interface LoginState {
  username: string;
  securityImageBase64: string;
  requiresOtp: boolean;
  returnUrl?: string;
  esMigrado?: boolean;
  estadoMigracion?: number;
  factorBloqueo?: number;
  segundoFactor?: number;
}

/**
 * @description
 * Servicio encargado de administrar y persistir el estado del proceso
 * de autenticación durante la sesión del usuario.
 */
import { STORAGE_KEYS } from '../constants/storage.constants';

@Injectable({ providedIn: 'root' })
export class LoginStateService {
  private readonly storageKey = STORAGE_KEYS.LOGIN_STATE;

  private readonly initialState: LoginState = {
    username: '',
    securityImageBase64: '',
    requiresOtp: false,
    esMigrado: false,
    estadoMigracion: 0,
    factorBloqueo: 0,
    segundoFactor: 0
  };

  private readonly stateSubject = new BehaviorSubject<LoginState>(this.loadState());

  public readonly state$ = this.stateSubject.asObservable();

  /**
   * @description
   * Recupera el estado de autenticación almacenado en sesión.
   * @return {LoginState} Retorna el estado almacenado o el estado inicial.
   */
  private loadState(): LoginState {
    try {
      const raw = sessionStorage.getItem(this.storageKey);

      if (raw) {
        const parsed = JSON.parse(raw) as Partial<LoginState>;
        return { ...this.initialState, ...parsed };
      }
    } catch {}

    return this.initialState;
  }

  /**
   * @description
   * Persiste el estado actual de autenticación en la sesión del navegador.
   */
  private saveState(): void {
    try {
      sessionStorage.setItem(this.storageKey, JSON.stringify(this.stateSubject.value));
    } catch {}
  }

  /**
   * @description
   * Obtiene el estado actual del proceso de autenticación.
   * @return {LoginState} Retorna el estado actual.
   */
  get currentState(): LoginState {
    return this.stateSubject.value;
  }

  /**
   * @description
   * Actualiza el nombre de usuario en el estado de autenticación.
   * @param username {string} Nombre del usuario.
   */
  setUsername(username: string): void {
    this.stateSubject.next({ ...this.currentState, username });
    this.saveState();
  }

  /**
   * @description
   * Actualiza la URL de retorno del proceso de autenticación.
   * @param returnUrl {string} URL de retorno.
   */
  setReturnUrl(returnUrl: string): void {
    this.stateSubject.next({ ...this.currentState, returnUrl });
    this.saveState();
  }

  /**
   * @description
   * Actualiza la imagen de seguridad asociada al usuario.
   * @param imageBase64 {string} Imagen de seguridad en formato Base64.
   */
  setSecurityImage(imageBase64: string): void {
    this.stateSubject.next({
      ...this.currentState,
      securityImageBase64: imageBase64
    });
    this.saveState();
  }

  /**
   * @description
   * Actualiza el indicador de requerimiento de OTP.
   * @param requiresOtp {boolean} Indica si el usuario requiere OTP.
   */
  setRequiresOtp(requiresOtp: boolean): void {
    this.stateSubject.next({ ...this.currentState, requiresOtp });
    this.saveState();
  }

  /**
   * @description
   * Actualiza el estado de migración Cash del usuario.
   * @param esMigrado {boolean} Indica si el usuario ha sido migrado.
   * @param estado {number} Estado actual de la migración.
   */
  setMigracionEstado(esMigrado: boolean, estado: number): void {
    this.stateSubject.next({
      ...this.currentState,
      esMigrado,
      estadoMigracion: estado
    });
    this.saveState();
  }

  /**
   * @description
   * Actualiza el factor de bloqueo asociado al usuario.
   * @param factorBloqueo {number} Factor de bloqueo del usuario.
   */
  setFactorBloqueo(factorBloqueo: number): void {
    this.stateSubject.next({
      ...this.currentState,
      factorBloqueo
    });
    this.saveState();
  }

  /**
   * @description
   * Guarda el número del factor de seguridad requerido para el 2FA.
   * @param segundoFactor {number} Número del factor (ej. 3 = correo, 20 = celular).
   */
  setSegundoFactor(segundoFactor: number): void {
    this.stateSubject.next({
      ...this.currentState,
      segundoFactor
    });
    this.saveState();
  }

  /**
   * @description
   * Limpia el estado de autenticación y elimina la información
   * persistida en la sesión del navegador.
   */
  clearState(): void {
    this.stateSubject.next(this.initialState);

    try {
      sessionStorage.removeItem(this.storageKey);
    } catch {}
  }
}