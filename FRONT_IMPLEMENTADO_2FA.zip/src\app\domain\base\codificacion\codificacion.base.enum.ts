/**
 * @description
 * Enumerado de tipo de roles.
 * @return {string} Retorna valor.
 */
export enum ROL_DISTRIBUCION_ENUM {
  CENTRODISTRIBUCION = 'CENTRODISTRIBUCION',
  CALLCENTER = 'CALLCENTER',
  AGENCIA = 'AGENCIA',
  
  CONTACTABILIDADCDD = 'CONTACTABILIDADCDD',
  ACTIVADORCDD = 'ACTIVADORCDD',
  SUPERVISORCDD = 'SUPERVISORCDD',
  BANCARIOSCDD = 'BANCARIOSCDD',
  CONSULTIVOCDD = 'CONSULTIVOCDD',
  CCENTERCDD = 'CCENTERCDD',
  COORDINADORCDD = 'COORDINADORAGENCIACDD',
  SUPERVISORAGENCIACDD = 'SUPERVISORAGENCIACDD',
  GESTORCDD = 'GESTORCAJACDD'
}

/**
 * @description
 * Enumerado de tipo de controles html.
 * @return {string} Retorna valor.
 */
export enum ROL_SALASVIP_ENUM {
  SALASVIP = 'SALASVIP',
  CALLCENTER = 'CALLCENTER'
}

/**
 * @description
 * Enumerado de tipo de controles html. 
 * @return {string} Retorna valor.
 */
export enum ROL_GAMING_LEALTAD_ENUM {
  GAMINGLEALTAD= 'LEALTAD'
}

/**
 * @description
 * Enumerado de tipo de controles html.
 * @return {string} Retorna valor.
 */
export enum MENSAJE_ERROR_CLIENTE_ENUM {
  USUARIO_CLAVE_INCORRECTO = 'informacionIngresadaIncorrecta',
  ACCESO_NO_AUTORIZADO = 'Acceso no autorizado!',
  PARAMETRO_REQUERIDO = 'Parametro es requirido',
  NO_EXISTE_MENU_ASIGNADO = 'No existe menu asignado al usuario',
  NO_EXISTE_ROLES_ASIGNADO = 'No existe roles asignados al usuario',
  NO_EXISTE_RUTAS_ASIGNADO = 'No existe rutas asignadas al usuario',
  NO_EXISTE_RUTAS__PREDETERMINAD = 'No existe ruta predeterminada asignada al rol del usuario'
}

/**
 * @description
 * Enumerado de mensajes de error para el modulo de centro de distribucion.
 * @return {string} Retorna valor.
 */
export enum MENSAJE_ERROR_DISTRIBUCION_ENUM {
  USUARIO_INCORRECTO = 'Usuario no encontrado',
  ERROR_GENERACION_CERTIFICADO_CREMACION = 'Error al intentar generar el certificado de cremacion de las tarjetas seleccionadas',
  ERROR_CREMAR_TARJETA = 'Error al intentar cremar las tarjetas seleccionadas',
  ERROR_CONSULTAR_TARJETAS_CANCELADAS = 'Error al consultar información de tarjetas canceladas',
  ERROR_CONSULTAR_TARJETAS = 'Error al consultar información de tarjetas',
  ERROR_SIN_RESULTADOS = 'El proceso no produjo ningún resultado',
  ADVERTENCIA_SELECCION_TARJETAS_CANCELADAS = 'Por favor, seleccione algún proceso',
  CORRECTO_PROCESO_EXITOSO = 'Procesos actualizados exitosamente',
  ERROR_CONSULTAR_CATALOGOS_CDD = 'Error al cargar los catalogos del Centro de distribucion',
  ERROR_IDENTIFICACION = 'Ingrese la identificación o número de tarjeta del cliente',
  ERROR_TIPOREPORTE = 'Seleccione un tipo de reporte',
  GENERAR_RERPORTE = 'Reporte generado exitosamente',
  ASIGNACION_EXITOSA = 'Usuario asignado correctamente',
  ERROR_GENERAR_REPORTE = 'Error al generar reporte',
  REDISTRIBUCION_EXITOSA = 'Redistribución existosa',
  ERROR_ASIGNAR_USUARIO = 'Error al asignar usuario',
  USUARIO_ENCONTRADO = 'Usuario Encontrado',
  ERROR_REDISTRIBUIR = 'Error al redistribuir',
  ERROR_ACTUALIZAR_PROCESOS = 'Error al actualizar procesos',
  ERROR_OBTENER_RESULTADOS = 'Error al obtener datos',
  CORRECTO_INICIO_PANTALLA = 'Inicio de pantalla exitoso',
  EXITO_ACTUALIZACION_STOCK = 'Actualización de stock exitosa',
  ERROR_ACTUALIZACION_STOCK = 'Error al actualizar stock',
  ADVERTENCIA_CAMPOS_OBLIGATORIOS_PRODUCTO_OFICINA = 'Por favor, seleccione las opciones de los campos obligatorios: Producto y Oficina',
  USUARIO_CORRECTO = 'Usuario encontrado',
  ADVERTENCIA_CAMPOS_OBLIGATORIOS_PRODUCTO_OFICINA_GESTION = 'Por favor, seleccione las opciones de los campos obligatorios: Producto, Oficina y Gestión para continuar',
  CONFIRMACION_ENVIOCDD = 'Actualización envío CDD exitoso.',
  GRID_SINRESULTADOS = 'No se encontraron resultados',
  ERROR_IMPRESION = 'Error de impresión',
  EXITO_IMPRESION = 'Se envió el documento a impresión',
  USUARIO_VACIO = 'Usuario no puede estar vacio',
  ADVETENCIA_VACIO = 'Por favor, seleccione un valor Usuario , Tipo Stock , Ofiicna ',
  OFICINA_VACIO = 'El campo oficina seleccionada es requerido. ',
  TIPO_STOCK_VACIO = 'El campo tipo de stock es requerido.',
  sELECCIION_VACIA_TARJETAS = 'Debe seleccionar tarjetas a reasignar',
  TELEFONO_AGREGADO = 'Teléfono agregado',
  INFORMACION_ENVIO_EXITOSA = 'Información de envío exitosa',
  COPIO_VALOR_MEMORIA = 'Se copio el valor del teléfono a memoria',
  COPIO_VALOR_MEMORIA_ERROR = 'Error al copiar el valor',
  ADVERTENCIA_CAMPOS_OBLIGATORIOS='Por favor, seleccione las opciones de los campos obligatorios',
  ERROR_ACTIVACION_TARJETA='Error en la activación tarjeta',
  ERROR_CONSULTA_FIRMAS='Error en la consulta de firma del cliente.',
  ERROR_CONSULTA_EXTRACTO_LEGAL='Error consulta información de extracto legal.',
  ERROR_CONSULTA_APODERADOS='Error consulta información de apoderados.',
  ERROR_CONSULTA_FORMAS_PAGO='Error consulta  información de apoderados.',
  ERROR_CONSULTA_SEGUROS='Error consulta  información de seguros.'

}

/**
 * @description
 * Enumerado de mensajes de error para Medios de Pagos.
 * @return {string} Retorna valor.
 */
export enum MENSAJES_MEDIOS_PAGO_ENUM {
  ERROR_CONSULTA_SALAS_VIP = 'Error al consultar las Salas VIP',
  EXITO_GUARDADO_SALA_VIP = 'Sala guardada exitosamente',
  ERROR_GUARDADO_SALA_VIP = 'Error al guardar la sala',
  ERROR_CONSULTA_SALAS_VIP_PARAMETRIZACIONES = 'Error al consultar las Parametrizaciones de Salas VIP',
  EXITO_GUARDADO_SALAS_VIP_PARAMETRIZACIONES = 'Parametrizaciones de Salas Vip guardadas exitosamente',
  ERROR_GUARDADO_SALAS_VIP_PARAMETRIZACIONES = 'Error al guardar las parametrizaciones',
  CORRECTO_REENVIO_COBRO = 'Reenvío de cobro exitoso',
  ERROR_CONSULTA_SALAS_VIP_REPORTE = 'Se ha producido un error al consultar información de reporte',
  EXITO_CONSULTA_SALAS_VIP_REPORTE = 'Consulta información reporte correcta',
  ERROR_TIPOREPORTE = 'Seleccione un tipo de reporte',
  ERROR_CONSULTA_SALAS_VIP_COBRO = 'Se ha producido un error al consultar información de cobro ingreso',
  EXITO_CONSULTA_SALAS_VIP_COBRO = 'Consulta información cobro ingreso correcta',
  ERROR_CONSULTA_SALAS_VIP_BENEFICIOS_INCREMENTALES = 'Error al consultar Beneficios Incrementales',
  EXITO_GUARDADO_SALAS_VIP_BENEFICIOS_INCREMENTALES = 'Beneficios guardados exitosamente',
  ERROR_GUARDADO_SALAS_VIP_BENEFICIOS_INCREMENTALES = 'Error al guardar los beneficios',
  ERROR_CONSULTA_COMERCIO_CADENA = 'Error al consultar el Comercio ',
  ERROR_GENERAR_SALAS_VIP_REPORTE = 'Se ha producido un error al generar reporte',
  EXITO_GENERAR_SALAS_VIP_REPORTE = 'Excel generado correctamente',
  ADVERTENCIA_GENERAR_SALAS_VIP_REPORTE = 'No se encontraron registros para generar el excel.',
  ADVERTENCIA_CONSULTA_SALAS_VIP_REPORTE = 'No se encontraron registros en la consulta.',
  ERROR_CEDULA_NECESARIA = 'Identificación es un campo necesario',
  ERROR_CEDULA_O_FECHA = 'Ingrese la fecha de busqueda o identificación.',
  ERROR_RANGO_FECHAS = 'El rango de fechas no puede ser mayor a 3 meses.'
}

/**
 * @description
 * Enumerado de mensajes de error para el modulo de centro de distribucion.
 * @return {string} Retorna valor.
 */
export enum TITULO_NOTIFICACION_ENUM {
  ERROR = 'Error',
  ADVERTENCIA = 'Advertencia',
  EXITO = 'Éxito',
  INFORMACION = 'Información'
}

/**
 * @description
 * Enumerado de tipo de usuario.
 * @return {string} Retorna valor.
 */
export enum USUARIO_SESION_ENUM {
  DATOS_SESION = 'currentUser',
  MENU_APLICACION = 'menuUser',
  RUTA_INICIO = 'rutaInicioSesion'
}

/**
 * @description
 * Enumerado de tipo de usuario.
 * @return {string} Retorna valor.
 */
export enum USUARIO_ESTADO_ENUM {
  HABIL = 'HABILITADO',
  NO_HABIL = 'DESHABILITADO'
}

/**
 * @description
 * Enumerado de para Opciones de Consulta Administracion Stock - Centro de Distribucion.
 * @return {string} Retorna valor.
 */
export enum OPCIONES_CONSULTA_ADMIN_STOCK_ENUM {
  IDENTIFICACION = 'Identificación',
  NUMERO_TARJETA = 'Número de tarjeta '
}

/**
 * @description
 * Enumerado para Catalogos de Centro de Distribucion.
 * @return {string} Retorna valor.
 */
export enum CATALOGO_DISTRIBUCION_ENUM {
  CATALOGO_INICIO_CDD = 'CDDCATINI',
  CATALOGO_PRODUCTO_TARJETA = 'CDDPROTC',
  CATALOGO_STOCK_ADMINISTRACION = 'CDDSTOADM',
  CATALOGO_REPORTE = 'CDDCATREP',
  CATALOGO_PROCESO_ENTREGA = 'CDDCATTRA',
  CATALOGO_ACTIVACION_TARJETA = 'MOTDEV',
  CATALOGO_CENTRO_DISTRIBUCION = 'CDDCATCON',
  CATALOGO_PROVINCIA_CIUDAD = 'CDDCATPRCI',
  CATALOGO_ESTADO_STOCK = 'CDRST'
}

/**
 * @description
 * Enumerado para Catalogos de Centro de Distribucion.
 * @return {string} Retorna valor.
 */
export enum CODIGO_CATALOGO_DISTRIBUCION_ENUM {
  CODIGO_PRODUCTOS = 1506,
  CODIGO_OFICINAS_CDD = 1508,
  CODIGO_TIPO_STOCK = 1507,
  CODIGO_ESTADO_STOCK = 1517,
  CODIGO_GESTION = 1501,
  CODIGO_CONTACTABILIDAD_DIRECCION = 7388
}

/**
 * @description
 * Enumerado de Catalogo de codigo de Tipos de Productos de Centro de Distribucion.
 * @return {number} Retorna valor.
 */
export enum CATALOGO_CODIGO_TIPO_PRODUCTO_DISTIBUCION_ENUM {
  TIPO_PRODUCTO_INGRESADA = 150001,
  TIPO_PRODUCTO_PORENVIAR = 150002,
  TIPO_PRODUCTO_REGESTION = 150003,
  TIPO_PRODUCTO_REZAGADA = 150004,
  TIPO_PRODUCTO_CREMACION = 150068,
  TIPO_PRODUCTO_CREMADA = 150657,
  TIPO_PRODUCTO_PRELIMINAR = 150172,
  TIPO_PRODUCTO_PRELIMINARNODESEA = 150555,
  TIPO_PRODUCTO_TODOS = 1
}

/**
 * @description
 * Enumerado de Catalogo de codigo de Tipos de Productos de Centro de Distribucion.
 * @return {number} Retorna valor.
 */
export enum CATALOGO_CODIGO_GESTIONES_DISTRIBUCION_ENUM {
  GESTION_PROCESO_ENTREGA = 150142
}

/**
 * @description
 * Enumerado de Catalogo de Descripciones de Tipos Stock en Centro de Distribucion.
 * @return {string} Retorna valor.
 */
export enum CATALOGO_DESCRIPCION_TIPO_STOCK_DISTIBUCION_ENUM {
  TIPO_TARJETA_STOCK = 'TC TIPO TARJETA STOCK',
  ESTADO_ENTREGA_DISTRIBUCION = 'ESTADO ENTREGA DISTRIBUCION'
}

/**
 * @description
 * Enumerado de Catalogo de Descripciones de Tipos Stock en Centro de Distribucion.
 * @return {string} Retorna valor.
 */
export enum CATALOGO_DESCRIPCION_CDD_DISTIBUCION_ENUM {
  CDD = 'ZONAS CDD'
}
/**
 * @description
 * Enumerado de Catalogo de Descripciones de Tipos Stock en Centro de Distribucion.
 * @return {number} Retorna valor.
 */
export enum CATALOGO_DESCRIPCION_CONSULTA_REPORTE_DISTIBUCION_ENUM {
  TIPO_CONSULTA_REPORTE = 'TIPO CONSULTA REPORTE'
}

/**
 * @description
 * Enumerado de Catalogo de Descripciones de los reportes de las salas vip
 * @return {number} Retorna valor.
 */
export enum CATALOGO_DESCRIPCION_CONSULTA_REPORTE_SALAS_VIP_ENUM {
  TIPO_REPORTE_SALAS_VIP = 'REPORTES SALAS VIP'
}

/**
 * @description
 * Enumerado de Catalogo de Descripciones de Tipos Stock en Centro de Distribucion.
 * @return {number} Retorna valor.
 */
export enum CATALOGO_DESCRIPCION_CONSULTA_TIPO_MENSAJERO_ENUM {
  TIPO_CONSULTA_MENSAJERO = 'TIPO MENSAJERO'
}

/**
 * @description
 * Enumerado de Catalogo de Descripciones de Tipos Stock en Centro de Distribucion.
 * @return {number} Retorna valor.
 */
export enum CATALOGO_DESCRIPCION_CONSULTA_ZONAS_CDD {
  TIPO_CONSULTA_ZONAS_CDD = 'ZONAS CDD',
  TIPO_CONSULTA_ENTREGA = 'TIPO DE ENTREGA'
}

/**
 * @description
 * Enumerado de Catalogo de Descripciones de Tipos Stock en Centro de Distribucion.
 * @return {number} Retorna valor.
 */
export enum CATALOGO_DESCRIPCION_CONSULTA_ACTIVACION_TARJETA {
  TIPO_CONSULTA_MOTIVO_DEVOLUCION = 'TC MOTIVOS DEVOLUCIÓN',
  TIPO_CONSULTA_CORTE = 'CORTE DE TARJETA',
  TIPO_CONSULTA_FECHA_PAGO = 'FECHA PAGO TARJETA',
  TIPO_CONSULTA_FORMAS_PAGO = 'FORMA DE PAGO TARJETA',
  TIPO_CONSULTA_TIPOS_PAGO = 'TIPO DE PAGO TARJETA'
}

export enum REPORTE_TIPOS_ENUM {
  REPORT_MOTIONS = 150625,
  REPORT_CONSOLIDATE_CONTACTABILITY = 150634,
  REPORT_CONSOLIDATE_ACTIVATION = 150633,
  REPORT_CONSOLIDATE_SUPERVISION= 150627,
  REPORT_STADISTICS = 150626,
  REPORT_INDIVIDUAL = 150624,
  REPORT_COURIER_INTERNO = 151501,
  REPORT_COURIER_EXTERNO = 151502,
  REPORT_ESTADO_STOCK = 151508
}
/**
 * @description
 */
export enum REPORTE_TIPOS_SALAS_VIP_ENUM {
  REPORTE_ACCESOS_COBROS_BENEFICIOS = 151300,
  REPORTE_COBROS = 151301,
  REPORTE_BENEFICIOS_INCREMENTALES = 151302
}

/**
 * @description
 * Enumerado de valores por default UbicacionOficina en Centro de Distribucion.
 */
export enum UBICACION_OFICINA_DEFAULT_ENUM {
  TIPO_PRODUCTO = 'S',
  CODIGO_NEGOCIO = 'O',
  ORIGEN = 'P'
}

/**
 * @description
 * Enumerado de valores para estado de impresion
 */
export enum CATALOGO_ESTADO_IMPRESION {
  TODOS = 'Todos|null',
  IMPRESOS = 'Impresos|true',
  SIN_IMPRIMIR = 'Sin Imprimir|false'
}

/**
 * @description
 * Enumerado de valores para estado de impresion
 */
export enum CATALOGO_GESTION_PRELIMINAR_RENOVACION {
  PENDIENTE_GENERAR = 'Pendiente Generar|1',
  PENDIENTE_IMPRESION = 'Pendiente Impresión|2',
  RENOVACION_NODESEA = 'Renovación no desea|3'
}

/**
 * @description
 * Enumerado de Catalogo de Descripciones de Tipos Stock en Centro de Distribucion.
 * @return {number} Retorna valor.
 */
export enum CATALOGO_DESCRIPCION_CONSULTA_FORMULARIO_CONTACTABILIDAD {
  TIPO_CONSULTA_OPCIONES_ENTREGA = 'OPCIONES ENTREGA',
  TIPO_CONSULTA_TIPO_MENSAJERO = 'TIPO MENSAJERO',
  TIPO_CONSULTA_MOTIVOS_RECHAZO = 'MOTIVOS RECHAZO',
  TIPO_CONSULTA_PROVINCIA = 'CODIGO DE PROVINCIA',
  TIPO_CONSULTA_CANTON = 'CODIGO DE CANTON'
}

/**
 * @description
 * Enumerado de Catalogo de Descripciones usadas en el formulario de contactabiliadad
 * @return {number} Retorna valor.
 */
export enum FORMULARIO_CONTACTABILIDAD {
  IDCATALOGOZONA = 1508,
  OPCIONESENTREGA = 1502,
  OPTIONCOURIER = 1503,
  OPCIONESRAZONES = 1504,
  IDCATALOGOPROVINCIA = 2103,
  IDCATALOGOCIUDAD = 2104,
  IDCASA = 7388,
  IDTRABAJO = 7389,
  IDOTRADIRECCION = 1,
  CANALENTREGAAGENCIA = 150092,
  CANADEENTREGAFUNCIONARIO = 150674,
  CANALID_TELEFONO = 150073,
  CANALID_WHATSAPP = 150074,
  CANALID_EMAIL = 150075
}

/**
 * @description
 * Enumerado de Catalogo de direcciones seleccionadas formulario de contactabiliadad
 * @return {string} Retorna valor.
 */
export enum FORMULARIO_CONTACTABILIDAD_DIRECCION_SELECCIONADA {
  ENTREGAAGENCIA = 'Agencia',
  ENTREGACASA = 'Domicilio',
  ENTREGATRABAJO = 'Trabajo',
  ENTREGAOTROS = 'Otra Direccion',
  FUNCIONARIO = 'Funcionario'
}

export enum CATALOGO_REPORTE_SALAS_VIP {
  SELECCIONE = 'Seleccione|null',
  REPORTE_ACCESOS = 'Reporte Accesos Cobros Beneficios|151080',
  REPORTE_COBROS = 'Reporte Cobros|151081',
  REPORTE_BENEFICIOS = 'Reporte Beneficios Incrementales|151082'
}

export enum NOMBRE_REPORTES_VIP {
  REPORTE_ACCESOS = 'Reporte_Accesos_Cobros_Beneficios',
  REPORTE_COBROS = 'Reporte_Cobros',
  REPORTE_BENEFICIOS = 'Reporte_Beneficios_Incrementales'
}
/**
 * @description
 * Enumerado tipo búsqueda
 */
export enum CATALOGO_TIPO_BUSQUEDA {
  TODOS = 'Todos|null',
  CEDULA = 'Cédula|0',
  RUC = 'Ruc|1'
}

/**
 * @description
 * Enumerado de tipo de controles html.
 * @return {string} Retorna valor.
 */
export enum ROL_METROPOLITAN_ENUM {
  METROPOLITAN = 'METROPOLITAN'
}

export enum CATALOGO_DESCRIPCION_CONSULTA_STOCK_ENUM {
  ESTADO_TARJETA_DISTRIBUCION = 'ESTADO ENTREGA DISTRIBUCION',
  TIPO_MENSAJERO = 'TIPO MENSAJERO',
  MOTIVOS_RECHAZO = 'MOTIVOS RECHAZO'
}
