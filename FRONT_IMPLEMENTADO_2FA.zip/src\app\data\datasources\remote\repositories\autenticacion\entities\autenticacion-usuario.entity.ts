﻿/**
 * @description
 * Entidad que representa la información corporativa y de directorio
 * del usuario autenticado.
 * NOTA: Las propiedades se manejan en Español. Se duplican en el idioma original 
 * (inglés) para garantizar la interoperabilidad con el backend (Active Directory).
 */
export interface UsuarioEntity {
  titulo?: string;
  descripcion?: string;
  oficinaEntregaFisica?: string;
  departamento?: string;
  compania?: string;
  direccion?: string;
  nombre?: string;
  nombreCuentaSAM?: string;
  correo?: string;
  gerente?: string;
  usuarioSipHabilitado?: string;
  federacionSipHabilitada?: string;
  accesoInternetSipHabilitado?: string;
  cedula?: string;

  title?: string;
  description?: string;
  physicalDeliveryOfficeName?: string;
  department?: string;
  company?: string;
  streetAddress?: string;
  name?: string;
  sAMAccountName?: string;
  mail?: string;
  manager?: string;
  'msRTCSIP-UserEnabled'?: string;
  'msRTCSIP-FederationEnabled'?: string;
  'msRTCSIP-InternetAccessEnabled'?: string;
}

/**
 * @description
 * Entidad que contiene la información del usuario autenticado
 * junto con los datos de acceso generados por el servicio de autenticación.
 * NOTA: Las propiedades se manejan en Español. Se duplican en el idioma original 
 * (inglés) para garantizar la interoperabilidad con OAuth2.
 */
export interface AutenticacionUsuarioEntity {
  usuario: UsuarioEntity;

  tokenAcceso?: string;
  tipoToken?: string;
  expiraEn?: string;

  access_token?: string;
  token_type?: string;
  expires_in?: string;
}
