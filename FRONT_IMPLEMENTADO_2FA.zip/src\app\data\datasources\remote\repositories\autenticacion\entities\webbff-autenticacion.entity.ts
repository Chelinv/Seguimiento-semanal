/**
 * @description
 * Interface base para respuestas del WebBFF.Produnet.
 */
export interface RespuestaDtoEntity<T> {
  data?: T;
  datos?: T;
  mensaje?: string;
  codigo?: number;
  esExitoso?: boolean;
}

/**
 * @description
 * Entidad DTO para la imagen de seguridad del usuario.
 */
export interface ImagenUsuarioModeloEntity {
  perfilUsuario?: boolean;
  guidImagen?: string;
  esEnrolamientoAlfred?: boolean;
  factorBloqueo?: number;
}

/**
 * @description
 * Entidad DTO para el estado de migracion Cash del usuario.
 */
export interface UsuarioMigracionModeloEntity {
  estadoMigracion?: boolean;
  fechaMigracion?: string | null;
  estado?: number;
  identificacionPrincipal?: string;
  idUsuario?: number;
}

export interface SegundoFactorModeloEntity {
  idFactor?: number;
  descripcion?: string;
  enmascarado?: string;
  tipoMecanismo?: string;
}

export interface EstadoSegundoFactorModeloEntity {
  tieneSegundoFactor?: boolean;
  segundoFactorActual?: number;
  idEstado?: number;
  estadoDispositivo?: string;
  listaSegundoFactor?: SegundoFactorModeloEntity[];
}
