import { Observable } from 'rxjs';
import {
  ImagenUsuarioModeloEntity,
  UsuarioMigracionModeloEntity,
  RespuestaDtoEntity,
  EstadoSegundoFactorModeloEntity
} from '../entities/webbff-autenticacion.entity';

export abstract class IWebBffAutenticacionAdapter {
  /**
   * @description
   * Consulta la imagen asociada a un usuario en el sistema.
   * @param nombreUsuario {string} Nombre de usuario a consultar.
   * @return {Observable<RespuestaDtoEntity<ImagenUsuarioModeloEntity>>} Retorna la respuesta con la información de la imagen del usuario.
   */
  abstract consultarUsuarioImagen(
    nombreUsuario: string
  ): Observable<RespuestaDtoEntity<ImagenUsuarioModeloEntity>>;

  /**
   * @description
   * Consulta el estado de migración del usuario en Cash.
   * Permite verificar si el usuario ya fue migrado y obtener
   * la información relacionada con dicho proceso.
   * @param usuario {string} Nombre o identificador del usuario.
   * @return {Observable<RespuestaDtoEntity<UsuarioMigracionModeloEntity>>} Retorna la respuesta con el estado e información de migración del usuario.
   */
  abstract consultarEstadoMigracionCash(
    usuario: string
  ): Observable<RespuestaDtoEntity<UsuarioMigracionModeloEntity>>;

  abstract consultarEstadoDobleFactor(): Observable<RespuestaDtoEntity<EstadoSegundoFactorModeloEntity>>;
  
  abstract solicitarCodigoDobleFactor(factorSeguridad: number): Observable<RespuestaDtoEntity<any>>;
  
  abstract validarCodigoDobleFactor(factorSeguridad: number, codigo: string): Observable<RespuestaDtoEntity<any>>;
}