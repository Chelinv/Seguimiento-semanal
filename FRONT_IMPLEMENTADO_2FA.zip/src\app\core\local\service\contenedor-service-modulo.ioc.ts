import { Provider } from '@angular/core';
import { ModuloAutorizadoService } from './implementation/modulo-autorizado.service';
import { IModuloAutorizadoService } from './interface/imodulo-autorizado.service';

/**
 * @description
 * Arreglo de provider de interceptores centralizado
 * @return {Provider[]} `Provider[]` Retorna arreglo de provider.
 */
export const CONTENEDOR_SERVICE_MODULO_IOC: Provider[] = [
  { provide: IModuloAutorizadoService, useClass: ModuloAutorizadoService, multi: true }
];
