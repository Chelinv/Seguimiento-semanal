const {
  shareAll,
  withModuleFederationPlugin
} = require('@angular-architects/module-federation/webpack');

const moduleFederationConfig = withModuleFederationPlugin({
  name: 'medios-pago-web-produbanco',
  exposes: {
    './AuthenticationModule': './src/app/presentation/authentication/authentication.module.ts'
  },

  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: 'auto'
    }),
    '@ngx-controlbase/core': {
      singleton: true,
      strictVersion: true,
      requiredVersion: '>=1.0.0 <5.0.0'
    }
  }
});

moduleFederationConfig.output.publicPath = 'auto';
module.exports = moduleFederationConfig;
