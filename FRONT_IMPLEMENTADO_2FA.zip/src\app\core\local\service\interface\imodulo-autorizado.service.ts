import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export abstract class IModuloAutorizadoService {
  /**
   * @description
   * Funcion para ejecutar la redireccion.
   * @param error `any` Tipo de codigo de estado de HttpStatusCode.
   * @return {void} `void`.
   */
  abstract redireccion(error: unknown): void;
}
