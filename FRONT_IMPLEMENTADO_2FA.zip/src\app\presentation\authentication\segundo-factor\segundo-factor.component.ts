import { Component, ElementRef, OnInit, QueryList, ViewChildren, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { FormArray, FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { forkJoin } from 'rxjs';
import { WebBffAutenticacionAdapter } from 'src/app/data/datasources/remote/repositories/autenticacion/adapters/webbff-autenticacion.adapter';
import { LoginStateService } from 'src/app/shared/services/login-state.service';

@Component({
  selector: 'pdn-segundo-factor',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, TranslateModule],
  templateUrl: './segundo-factor.component.html',
  styleUrls: ['./segundo-factor.component.scss']
})
export class SegundoFactorComponent implements OnInit {
  public form!: FormGroup;
  public loading = signal(false);
  public mensajeErrorInterno = signal('');

  public factorActual = signal<number>(3);
  public factorInicial = signal<number>(3);
  
  public correoEnmascarado = signal<string>('');
  public celularEnmascarado = signal<string>('');
  
  public enmascarado = computed(() => {
    return this.factorActual() === 3 ? this.correoEnmascarado() : this.celularEnmascarado();
  });

  public coordenadasMensaje = signal<string>('');

  private originalReturnUrl = '/';

  @ViewChildren('otpInput') otpInputs!: QueryList<ElementRef<HTMLInputElement>>;

  constructor(
    private readonly fb: FormBuilder,
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly webBffAdapter: WebBffAutenticacionAdapter,
    private readonly loginState: LoginStateService
  ) {
    this.form = this.fb.group({
      otp: this.fb.array(new Array(6).fill('').map(() => new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z0-9]$')])))
    });
  }

  get otpControls(): FormArray {
    return this.form.get('otp') as FormArray;
  }

  ngOnInit(): void {
    const queryParams = this.route.snapshot.queryParams;
    this.originalReturnUrl = queryParams['originalReturnUrl'] || queryParams['returnUrl'] || queryParams['ReturnUrl'] || '/';

    if (this.originalReturnUrl.includes('segundo-factor')) {
      this.originalReturnUrl = '/';
    }

    const factor = this.loginState.currentState.segundoFactor ?? 3;
    this.factorActual.set(factor);
    this.factorInicial.set(factor);

    if (factor === 1) {
      const otpArray = this.form.get('otp') as FormArray;
      while (otpArray.length > 4) {
        otpArray.removeAt(otpArray.length - 1);
      }
    }

    this.solicitarCodigo(factor);
  }

  /**
   * @description
   * Solicita el código OTP y los datos de contacto en paralelo.
   * El enmascarado se obtiene de /Usuarios/DatosContacto (pendiente de backend).
   * Si el endpoint de DatosContacto falla o no está disponible, el mensaje
   * se muestra igual pero sin el dato enmascarado (catchError ya está en el adapter).
   */
  private solicitarCodigo(factor: number): void {
    forkJoin({
      otp: this.webBffAdapter.solicitarCodigoDobleFactor(factor),
      contacto: this.webBffAdapter.consultarDatosContacto()
    }).subscribe({
      next: ({ otp, contacto }) => {
        if (contacto.esExitoso) {
          this.correoEnmascarado.set(contacto.correoEnmascarado ?? '');
          this.celularEnmascarado.set(contacto.celularEnmascarado ?? '');
        }

        if (factor === 1 && otp.esExitoso) {
          this.configurarMensajeCoordenadas(otp);
        }

        if (!otp.esExitoso) {
          this.mensajeErrorInterno.set(otp.mensaje || 'No se pudo enviar el código. Intente nuevamente.');
        }
      },
      error: () => {
        this.mensajeErrorInterno.set('Ocurrió un error al preparar el factor de seguridad.');
      }
    });
  }

  private configurarMensajeCoordenadas(otp: any): void {
    const otpAny = otp as any;
    const datosPayload = otpAny.Datos || otp.datos || otp.data;
    const coords = datosPayload?.Coordenadas || datosPayload?.coordenadas;
    let msg = otp.mensaje && otp.mensaje !== 'OK' ? otp.mensaje : '';
    
    if (coords && coords.length > 0) {
      const coordsStr = coords.join('- ');
      if (!msg || msg === 'OK') {
         msg = `Ingresa las coordenadas: <strong>${coordsStr}</strong> de tu Tarjeta`;
      } else if (msg.includes(coordsStr)) {
         msg = msg.replace(coordsStr, `<strong>${coordsStr}</strong>`);
      }
    } else {
       msg = msg || 'Ingresa las coordenadas de tu tarjeta de seguridad';
    }
    this.coordenadasMensaje.set(msg);
  }


  public confirmar(): void {
    if (this.form.invalid) return;

    const codigoStr = this.otpControls.value.join('');
    this.loading.set(true);
    
    this.webBffAdapter.validarCodigoDobleFactor(this.factorActual(), codigoStr).subscribe({
      next: (res) => {
        if (res.esExitoso) {
          window.location.href = this.originalReturnUrl;
        } else {
          this.loading.set(false);
          this.mensajeErrorInterno.set(res.mensaje || 'Código incorrecto. Por favor, intente más tarde.');
        }
      },
      error: () => {
        this.loading.set(false);
        this.mensajeErrorInterno.set('Ocurrió un error inesperado. Por favor, intente más tarde.');
      }
    });
  }

  public cambiarMetodo(): void {
    const nuevoFactor = this.factorActual() === 3 ? 20 : 3;
    this.factorActual.set(nuevoFactor);
    this.solicitarCodigo(nuevoFactor);
    this.otpControls.reset();
  }

  public regresar(): void {
    this.router.navigate(['/authentication/ingreso-clave'], { queryParamsHandling: 'preserve' });
  }

  public cancelar(): void {
    this.router.navigate(['/authentication/ingreso-usuario'], { queryParamsHandling: 'preserve' });
  }

  

  onInput(event: Event, index: number): void {
    const input = event.target as HTMLInputElement;
    let value = input.value;
    
    if (/[^a-zA-Z0-9]/.test(value)) {
      value = value.replace(/[^a-zA-Z0-9]/g, '');
      this.otpControls.at(index).setValue(value);
    }
    
    if (value && index < this.otpInputs.length - 1) {
      this.otpInputs.toArray()[index + 1].nativeElement.focus();
    }
  }

  onKeyDown(event: KeyboardEvent, index: number): void {
    if (event.key === 'Backspace') {
      const currentValue = this.otpControls.at(index).value;
      if (!currentValue && index > 0) {
        this.otpInputs.toArray()[index - 1].nativeElement.focus();
      }
    }
  }

  onFocus(index: number): void {
    this.otpInputs.toArray()[index].nativeElement.select();
  }

  

  public tituloFactor(): string {
    if (this.factorActual() === 10) return 'codigoSeguridad';
    if (this.factorActual() === 1) return 'codigoSeguridad';
    return this.factorActual() === 3 ? 'codigoSeguridad' : 'codigoEnviadoCelular';
  }

  public iconoFactor(): string {
    if (this.factorActual() === 1) return 'assets/images/Banca_tarjeta_coordenadas.svg';
    if (this.factorActual() === 10) return 'assets/images/icono_entrust.svg';
    return this.factorActual() === 3 ? 'assets/images/icono_correo_otp.svg' : 'assets/images/icono_telefono_otp.svg';
  }

  public mensajeFactor(): string {
    if (this.factorActual() === 1) return 'ingresaCodigoCoordenadas';
    if (this.factorActual() === 10) return 'ingresaCodigoEntrust';
    return this.factorActual() === 3 ? 'ingresaCodigoCorreo' : 'ingresaCodigoCelular';
  }

  public textoFallback(): string {
    if (this.factorActual() === 1 || this.factorActual() === 10) return 'solicitaCodigoCorreoAqui';
    return this.factorActual() === 3 ? 'solicitaCodigoCelularAqui' : 'solicitaCodigoCorreoAqui';
  }
}
