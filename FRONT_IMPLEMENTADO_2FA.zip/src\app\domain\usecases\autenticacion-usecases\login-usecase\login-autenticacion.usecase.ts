import { Injectable } from '@angular/core';
import { HttpStatusCode } from '@angular/common/http';
import { ExcepcionClienteError, Param, Usecase } from '@ngx-controlbase/core';
import { Observable } from 'rxjs';
import { AutenticacionUsuarioModel } from '../../../models';
import { MENSAJE_ERROR_CLIENTE_ENUM } from '../../../base/codificacion/codificacion.base.enum';
import { IAutenticacionRepository } from 'src/app/domain/repositories';

/**
 * @description
 * Clase para procesar el caso de uso de autenticacion del usuario
 */
@Injectable({ providedIn: 'root' })
export class LoginAutenticacionUsecase
  implements Usecase<Param<AutenticacionUsuarioModel>, Observable<AutenticacionUsuarioModel>>
{
  constructor(private readonly iAutenticacionRepository: IAutenticacionRepository) {}

  /**
   * @description
   * Funcion para ejecutar el proceso de login del usuario.
   * @param param {Param<AutenticacionUsuarioModel>} Objeto con los datos para el proceso a ejecutar.
   * @return {Observable<AutenticacionUsuarioModel>} Retorno objeto con la respuesta del proceso.
   */
  execute(param?: Param<AutenticacionUsuarioModel>): Observable<AutenticacionUsuarioModel> {
    if (!param) {
      throw new ExcepcionClienteError(
        HttpStatusCode.BadRequest,
        MENSAJE_ERROR_CLIENTE_ENUM.PARAMETRO_REQUERIDO
      );
    }

    const { username, password } = param.payload;
    return this.iAutenticacionRepository.login(username ?? '', password ?? '');
  }
}
