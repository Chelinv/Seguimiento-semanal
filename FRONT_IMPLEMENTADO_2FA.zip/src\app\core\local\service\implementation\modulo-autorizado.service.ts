import { HttpStatusCode } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ExcepcionClienteError } from '@ngx-controlbase/core';
import { environment } from 'src/environments/environment';
import { IModuloAutorizadoService } from '../interface/imodulo-autorizado.service';
import { MENSAJE_ERROR_CLIENTE_ENUM } from 'src/app/domain/base/codificacion';

@Injectable({
  providedIn: 'root'
})
export class ModuloAutorizadoService implements IModuloAutorizadoService {
  private readonly standalone = environment.autenticacionStandalone;

  constructor(private readonly router: Router) {
    try {
      const port = window.location.port;
      if (environment.host.port === port && this.standalone) {
        throw new ExcepcionClienteError(
          HttpStatusCode.Unauthorized,
          MENSAJE_ERROR_CLIENTE_ENUM.ACCESO_NO_AUTORIZADO
        );
      }
    } catch (error: unknown) {
      this.redireccion(error);
    }
  }

  /**
   * @description
   * Funcion para ejecutar la redireccion.
   * @param error `any` Tipo de codigo de estado de HttpStatusCode.
   * @return {void} `void`.
   */
  redireccion(error: unknown): void {
    const err = error as { status?: number, message?: string };
    const statusCode = err.status! && err.status !== undefined ? err.status : 0;
    const message = err.message! && err.message !== undefined ? err.message : '';
    const ruta =
      message !== ''
        ? `/application/error-message/${statusCode}?message=${message}`
        : `/application/error-message/${statusCode}`;

    this.router.navigate([ruta]);
  }
}
