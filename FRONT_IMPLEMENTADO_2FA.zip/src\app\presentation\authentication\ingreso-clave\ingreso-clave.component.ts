import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { LoginStateService } from 'src/app/shared/services/login-state.service';

/**
 * @description
 * Componente encargado de gestionar el ingreso de la clave del usuario
 * dentro del flujo de autenticación.
 * Permite validar las credenciales y completar el proceso de inicio de sesión.
 */
@Component({
  selector: 'pdn-ingreso-clave',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, TranslateModule],
  templateUrl: './ingreso-clave.component.html',
  styleUrls: ['./ingreso-clave.component.scss']
})
export class IngresoClaveComponent implements OnInit {
  public form!: FormGroup;
  public readonly loading = signal(false);
  public securityImageBase64 = '';
  public mostrarClave = false;
  public mensajeError = signal('');
  public mensajeErrorInterno = signal('');

  constructor(
    private readonly fb: FormBuilder,
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly loginState: LoginStateService,
    private readonly http: HttpClient
  ) {
    this.form = this.fb.group({
      password: ['', Validators.required]
    });
  }

  /**
   * @description
   * Inicializa la información necesaria para el flujo de autenticación
   * y valida la existencia del usuario en el estado de sesión.
   * Redirecciona al paso de ingreso de usuario cuando no existe
   * información previa almacenada.
   */
  ngOnInit(): void {
    const state = this.loginState.currentState;
    this.securityImageBase64 = state.securityImageBase64;

    if (!state.username) {
      this.router.navigate(['/authentication/ingreso-usuario']);
    }

    this.route.queryParams.subscribe(params => {
      const error = params['error'];
      if (error) {
        if (error === 'timeout' || error === 'server_error' || error === 'internal_error') {
          this.mensajeErrorInterno.set('Ocurrió un error inesperado. Por favor, intente más tarde.');
        } else {
          this.mensajeError.set('informacionIncorrectaClave');
        }
      
        this.router.navigate([], {
          relativeTo: this.route,
          queryParams: { error: null },
          queryParamsHandling: 'merge',
          replaceUrl: true
        });
      }
    });
  }

  /**
   * @description
   * Retorna al paso de ingreso de usuario conservando la URL
   * de retorno cuando esta se encuentra disponible.
   */
  public regresar(): void {
    const returnUrl = this.loginState.currentState.returnUrl;

    this.router.navigate(['/authentication/ingreso-usuario'], {
      queryParams: returnUrl ? { returnUrl } : undefined
    });
  }

  /**
   * @description
   * Envía las credenciales utilizando HttpClient hacia el endpoint /login
   * y procesa la respuesta JSON para manejar el flujo 2FA o redirección.
   */
  public onSubmit(): void {
    if (!this.loginState.currentState.username) {
      return;
    }
    
    const password = this.form.get('password')?.value;
    if (!password) {
      return;
    }

    this.loading.set(true);
    this.mensajeError.set('');

    const username = this.loginState.currentState.username;
    const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);
    formData.append('returnUrl', returnUrl);

    this.http.post<any>('login', formData, { withCredentials: true }).subscribe({
      next: (res) => {
        this.loading.set(false);
        if (res.EsExitoso) {
          
          if (res.Datos?.token) {
            localStorage.setItem('auth_token', res.Datos.token);
          }

          
          const factor = res.Datos?.segundoFactor;
          if (factor === 3 || factor === 20 || factor === 10 || factor === 1) {
            this.loginState.setSegundoFactor(factor);
            this.router.navigate(['/authentication/segundo-factor'], {
              queryParams: { returnUrl }
            });
          } else {
            window.location.href = returnUrl;
          }
        } else {
          this.mensajeError.set('informacionIncorrectaClave');
        }
      },
      error: () => {
        this.loading.set(false);
        this.mensajeErrorInterno.set('Ocurrió un error inesperado. Por favor, intente más tarde.');
      }
    });
  }
}