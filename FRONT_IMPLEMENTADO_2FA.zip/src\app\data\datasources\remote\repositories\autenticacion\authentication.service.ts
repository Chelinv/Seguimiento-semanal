﻿import { Injectable } from '@angular/core';
import {
  ExcepcionClienteError,
  ILocalStorageService,
  Result,
  UnsubscribeOnDestroyAdapter
} from '@ngx-controlbase/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { AutenticacionUsuarioModel } from '../../../../../domain/models/autenticacion-usuario.model';
import { AutenticacionRepositoryMapper } from './mappers/autenticacion-repository.mapper';
import { IAutenticacionAdapter, IWebBffAutenticacionAdapter } from './adapters';
import { UsuarioImagenWebBffMapper } from './mappers/webbff-autenticacion-repository.mapper';
import { USUARIO_SESION_ENUM } from 'src/app/domain/base/codificacion';
import { HttpStatusCode } from '@angular/common/http';
import { IAutenticacionRepository } from 'src/app/domain/repositories';

@Injectable({
  providedIn: 'root'
})

export class AuthenticationService
  extends UnsubscribeOnDestroyAdapter
  implements IAutenticacionRepository
{
  private usuarioActual!: BehaviorSubject<AutenticacionUsuarioModel>;
  private readonly mapper = new AutenticacionRepositoryMapper();
  private readonly imagenMapper = new UsuarioImagenWebBffMapper();
  
  /**
   * @description
   * Constructor del servicio.
   * @param iLocalService Servicio de almacenamiento local.
   * @param iAutenticacionAdapter Adaptador de autenticacion.
   */
  constructor(
    private readonly iLocalService: ILocalStorageService,
    private readonly iAutenticacionAdapter: IAutenticacionAdapter,
    private readonly iWebBffAutenticacionAdapter: IWebBffAutenticacionAdapter
  ) {
    super();
    this.consultarUsuarioSesion();
  }

  /**
   * @description
   * Funcion para consultar los datos del usuario del localstorage.
   * @return {void} `void`.
   */
  private consultarUsuarioSesion(): void {
    this.usuarioActual = new BehaviorSubject<AutenticacionUsuarioModel>(
      JSON.parse(this.iLocalService.getData(USUARIO_SESION_ENUM.DATOS_SESION) || '{}')
    );
  }

  /**
   * @description
   * Funcion para consultar los datos del usuario.
   * @return {AutenticacionUsuarioModel} `AutenticacionUsuarioModel` Retorna respuesta del proceso.
   */
  public get getSesionUsuario(): AutenticacionUsuarioModel {
    this.consultarUsuarioSesion();
    return this.usuarioActual.value;
  }

  /**
   * @description
   * Funcion para guardar los datos del usuario.
   * @param datos `AutenticacionUsuarioModel` Objeto con los datos del usuario.
   * @return {void} `void`.
   */
  private setSesionUsuario(datos: AutenticacionUsuarioModel): void {
    this.usuarioActual.next(datos);
  }

  /**
   * @description
   * Funcion para el login del usuario en la aplicacion.
   * @param username `string` Nombre del usuario.
   * @param password `string` Clave del usuario.
   * @return {Observable<AutenticacionUsuarioModel>} `Observable<AutenticacionUsuarioModel>` Retorna objeto con datos de respuesta del proceso.
   */
  public login(username: string, password: string): Observable<AutenticacionUsuarioModel> {
    return new Observable((observer) => {
      this.iLocalService.removeData(USUARIO_SESION_ENUM.DATOS_SESION);
      this.iLocalService.removeData(USUARIO_SESION_ENUM.MENU_APLICACION);

      if (username === undefined || username === '' || password === undefined || password === '') {
        throw new ExcepcionClienteError(HttpStatusCode.Unauthorized);
      }

      this.iAutenticacionAdapter
        .login(username, password)
        .pipe(
          map((respuesta) => {
            const usuario: AutenticacionUsuarioModel = this.mapper.mapFrom(respuesta);

            this.iLocalService.saveKey(usuario.token!);
            this.iLocalService.saveData(USUARIO_SESION_ENUM.DATOS_SESION, JSON.stringify(usuario));
            this.setSesionUsuario(usuario);

            return usuario;
          })
        )
        .subscribe({
          next: (usuario) => {
            observer.next(usuario);
            observer.complete();
          },
          error: (err) => {
            observer.error(err);
          }
        });
    });
  }

  /**
   * @description
   * Funcion para el cerrar las sesion del usuario en la aplicacion.
   * @return {Observable<Result>} `Observable<Result>`  Retorna objeto con datos de respuesta del proceso.
   */
  public logout(): Observable<Result> {
    this.iLocalService.clearData();
    this.setSesionUsuario(new AutenticacionUsuarioModel());

    return of({ success: false });
  }

  /**
   * @description
   * Funcion para consultar si el usuario tiene configurada una imagen de seguridad.
   * @param username `string` Nombre del usuario.
   * @return {Observable<Result>} `Observable<Result>` Retorna objeto con datos de respuesta.
   */
  public validarUsuarioImagen(username: string): Observable<Result> {
    return this.iWebBffAutenticacionAdapter.consultarUsuarioImagen(username).pipe(
      map(respuesta => {
        const data = this.imagenMapper.mapFrom(respuesta);
        return {
          success: data.esExitoso,
          message: data.imagenBase64
        } as unknown as Result;
      })
    );
  }
}



