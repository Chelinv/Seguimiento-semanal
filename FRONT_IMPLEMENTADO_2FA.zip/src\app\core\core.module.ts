import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CONTENEDOR_UTILITARIAN_IOC, CONTENEDOR_SERVICE_IOC } from '@ngx-controlbase/core';

@NgModule({
  declarations: [],
  imports: [CommonModule],
  providers: [...CONTENEDOR_UTILITARIAN_IOC, ...CONTENEDOR_SERVICE_IOC],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CoreModule {}
