import { Observable } from 'rxjs';
import {
  AutenticacionUsuarioEntity
} from '../entities/autenticacion-usuario.entity';

export abstract class IAutenticacionAdapter {
  /**
   * @description
   * Realiza el proceso de autenticacion del usuario.
   * @param username {string} Nombre del usuario.
   * @param password {string} Clave del usuario.
   * @return {Observable<AutenticacionUsuarioEntity>} Retorna la respuesta del proceso de login.
   */
  abstract login(username: string, password: string): Observable<AutenticacionUsuarioEntity>;

}
