import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { forkJoin } from 'rxjs';
import { LoginStateService } from 'src/app/shared/services/login-state.service';
import { LoginService } from 'src/app/shared/services/login.service';
import { environment } from 'src/environments/environment';
import { DialogModule } from 'primeng/dialog';
import { MENSAJE_ERROR_CLIENTE_ENUM } from 'src/app/domain/base/codificacion/codificacion.base.enum';

/**
 * @description
 * Captura el nombre de usuario y los parámetros de redirección.
 * Permite consultar la imagen de seguridad y validar el estado de
 * migración antes de continuar con el proceso de inicio de sesión.
 */
@Component({
  selector: 'pdn-ingreso-usuario',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DialogModule, TranslateModule],
  templateUrl: './ingreso-usuario.component.html',
  styleUrls: ['./ingreso-usuario.component.scss']
})
export class IngresoUsuarioComponent implements OnInit {
  public form!: FormGroup;
  public readonly loading = signal(false);
  public mostrarDialogoMigracion = signal(false);
  public rutaCashManagement = '';
  public mensajeError = signal('');
  public mensajeErrorInterno = signal('');

  constructor(
    private readonly fb: FormBuilder,
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly loginState: LoginStateService,
    private readonly loginService: LoginService
  ) {
    this.form = this.fb.group({
      username: ['', Validators.required]
    });
  }

  /**
   * @description
   * Inicializa la información requerida para el flujo de autenticación,
   * recuperando los parámetros enviados a la página y gestionando los
   * mensajes de error asociados al proceso de inicio de sesión.
   */
  ngOnInit(): void {
    this.route.queryParamMap.subscribe(params => {
      const returnUrl = params.get('returnUrl');
      const error = params.get('error');

      if (error) {
        const state = this.loginState.currentState;
        if (state.username && state.securityImageBase64) {
          const queryParams: any = { error };
          if (returnUrl) {
            queryParams.returnUrl = returnUrl;
          }
          this.router.navigate(['/authentication/ingreso-clave'], { queryParams });
          return;
        } else {
          this.mensajeError.set(MENSAJE_ERROR_CLIENTE_ENUM.USUARIO_CLAVE_INCORRECTO);
        }
      } else {
        this.loginState.clearState();
        localStorage.removeItem('auth_token');
      }
      if (returnUrl) {
        this.loginState.setReturnUrl(returnUrl);
      }
    });
  }

  /**
   * @description
   * Procesa el envío del formulario de ingreso de usuario.
   * Consulta en paralelo la imagen de seguridad y el estado
   * de migración del usuario para determinar el siguiente paso
   * dentro del flujo de autenticación.
   */
  public onSubmit(): void {
    if (this.form.invalid) {
      return;
    }

    const username = this.form.get('username')?.value?.trim();

    if (!username) {
      return;
    }

    this.loading.set(true);

    forkJoin({
      imagen: this.loginService.consultarImagenUsuario(username),
      migracion: this.loginService.consultarEstadoMigracionCash(username)
    }).subscribe({
      next: ({ imagen, migracion }) => {
        this.loading.set(false);

        if (imagen.esExitoso === false) {
          if (imagen.codigo === '401') {
            this.mensajeErrorInterno.set('Ocurrió un error inesperado. Por favor, intente más tarde.');
          } else if (imagen.mensaje?.includes('Core.Autenticacion') || imagen.codigo === '404' || imagen.codigo === '500' || imagen.codigo === '504') {
            this.mensajeErrorInterno.set('Ocurrió un error inesperado. Por favor, intente más tarde.');
          } else {
            this.mensajeError.set(MENSAJE_ERROR_CLIENTE_ENUM.USUARIO_CLAVE_INCORRECTO);
          }
          return;
        }

        this.mensajeError.set('');
        this.mensajeErrorInterno.set('');

        if (migracion.estadoMigracion) {
          this.rutaCashManagement = environment.rutaCashManagement;
          this.mostrarDialogoMigracion.set(true);
          this.loginState.setMigracionEstado(true, migracion.estado ?? 0);
          return;
        }

        this.loginState.setUsername(username);
        this.loginState.setSecurityImage(imagen.imagenBase64 ?? '');
        this.loginState.setFactorBloqueo(imagen.factorBloqueo ?? 0);

        const returnUrl = this.loginState.currentState.returnUrl;

        this.router.navigate(['/authentication/ingreso-clave'], {
          queryParams: returnUrl ? { returnUrl } : undefined
        });
      },
      error: (err: any) => {
        if (err?.status === 0 || err?.status >= 500) {
          this.mensajeErrorInterno.set('Ocurrió un error inesperado. Por favor, intente más tarde.');
        } else {
          this.mensajeError.set(MENSAJE_ERROR_CLIENTE_ENUM.USUARIO_CLAVE_INCORRECTO);
        }
        this.loading.set(false);
      }
    });
  }
}