import { Component, OnInit } from '@angular/core';
import { Event, Router, NavigationStart, NavigationEnd } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { TranslateService } from '@ngx-translate/core';
import { EsperaSpinnerService} from '@ngx-controlbase/core';

@Component({
  selector: 'pdn-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public loading = false;
  public currentUrl!: string;

  constructor(
    private readonly primengConfig: PrimeNGConfig,
    private readonly loadingBar: LoadingBarService,
    private readonly router: Router,
    private readonly esperaSpinnerService: EsperaSpinnerService,
    private readonly translate: TranslateService
  ) {
    this.translate.addLangs(['es', 'en']);
    this.translate.setDefaultLang('es');
    this.translate.use('es');
  }

  ngOnInit() {
    this.primengConfig.ripple = true;
    this.router.events.subscribe((routerEvent: Event) => {
      if (routerEvent instanceof NavigationStart) {
        this.currentUrl = routerEvent.url.substring(routerEvent.url.lastIndexOf('/') + 1);
      }
      if (routerEvent instanceof NavigationEnd) {
        window.scrollTo(0, 0);
      }
    });

    this.router.events.subscribe((evento) => {
      if (evento instanceof NavigationStart) {
        this.loading = true;
        this.esperaSpinnerService.show();
      } else if (evento instanceof NavigationEnd) {
        this.loading = false;
        this.esperaSpinnerService.hide();
      }
    });
  }

  startLoading() {
    this.loadingBar.useRef().start();
  }

  stopLoading() {
    this.loadingBar.useRef().complete();
  }
}
