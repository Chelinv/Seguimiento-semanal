import { Provider } from '@angular/core';
import {
  IAutenticacionInteractor,
  ILocalStorageService,
  ISesionStorageService,
  LocalStorageService,
  SesionStorageService
} from '@ngx-controlbase/core';
import { IAutenticacionRepository } from 'src/app/domain/repositories';
import { GetSesionUsuarioUsecase } from 'src/app/domain/usecases/autenticacion-usecases/get-sesion-usuario-usecase/get-sesion-usuario.usecase';
import { LoginAutenticacionUsecase } from 'src/app/domain/usecases/autenticacion-usecases/login-usecase/login-autenticacion.usecase';
import { LogoutAutenticacionUsecase } from 'src/app/domain/usecases/autenticacion-usecases/logout-usecase/logout-autenticacion.usecase';
import {
  IAutenticacionAdapter,
  AutenticacionAdapter
} from '../datasources/remote/repositories/autenticacion/adapters';
import { AuthenticationService } from '../datasources/remote/repositories/autenticacion/authentication.service';
import { AutenticacionInteractor } from '../interactors/implementations';
import { IWebBffAutenticacionAdapter } from '../datasources/remote/repositories/autenticacion/adapters/iwebbff-autenticacion.adapter';
import { WebBffAutenticacionAdapter } from '../datasources/remote/repositories/autenticacion/adapters/webbff-autenticacion.adapter';

export const AUTENTICACION_IOC: Provider[] = [
  {
    provide: ILocalStorageService,
    useClass: LocalStorageService
  },
  {
    provide: ISesionStorageService,
    useClass: SesionStorageService
  },
  {
    provide: IAutenticacionInteractor,
    useClass: AutenticacionInteractor
  },
  {
    provide: IAutenticacionAdapter,
    useClass: AutenticacionAdapter
  },
  {
    provide: IAutenticacionRepository,
    useClass: AuthenticationService
  },
  {
    provide: AutenticacionAdapter,
    useClass: AutenticacionAdapter
  },
   {
    provide: IWebBffAutenticacionAdapter,
    useClass: WebBffAutenticacionAdapter
  },
  {
    deps: [ILocalStorageService, IAutenticacionAdapter, IWebBffAutenticacionAdapter],
    provide: AuthenticationService,
    useFactory: (localService: ILocalStorageService, adapter: IAutenticacionAdapter, webBffAdapter: IWebBffAutenticacionAdapter) => new AuthenticationService(localService, adapter, webBffAdapter)
  },
  {
    deps: [IAutenticacionRepository],
    provide: LoginAutenticacionUsecase,
    useFactory: (repository: IAutenticacionRepository) => new LoginAutenticacionUsecase(repository)
  },
  {
    deps: [IAutenticacionRepository],
    provide: LogoutAutenticacionUsecase,
    useFactory: (repository: IAutenticacionRepository) => new LogoutAutenticacionUsecase(repository)
  },
  {
    deps: [IAutenticacionRepository],
    provide: GetSesionUsuarioUsecase,
    useFactory: (repository: IAutenticacionRepository) => new GetSesionUsuarioUsecase(repository)
  } 
];
