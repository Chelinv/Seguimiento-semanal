import { HttpClient, HttpHeaders, HttpBackend } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { WEBBFF_AUTENTICACION_ENUM, CABECERAS_WEBBFF_ENUM } from 'src/app/domain/base/codificacion/webbff-autenticacion.enum';
import { IWebBffAutenticacionAdapter } from './iwebbff-autenticacion.adapter';
import { 
  ImagenUsuarioModeloEntity, 
  UsuarioMigracionModeloEntity, 
  RespuestaDtoEntity,
  EstadoSegundoFactorModeloEntity
} from '../entities/webbff-autenticacion.entity';

@Injectable({
  providedIn: 'root'
})
export class WebBffAutenticacionAdapter implements IWebBffAutenticacionAdapter {
  private readonly rawHttp: HttpClient;

  constructor(handler: HttpBackend) {
    this.rawHttp = new HttpClient(handler);
  }

  /**
   * @description
   * Genera las cabeceras requeridas por el WebBFF y Core.Autenticacion.
   * Sin estas cabeceras, Core.Autenticacion no puede resolver el Tenant ni la imagen base.
   * @return {{ headers: HttpHeaders }} Retorna las cabeceras requeridas.
   */
  private getHeaders(): { headers: HttpHeaders } {
    const token = localStorage.getItem('auth_token');

    let headers = new HttpHeaders({
      [CABECERAS_WEBBFF_ENUM.NOMBRES.CANAL]: CABECERAS_WEBBFF_ENUM.VALORES_DEFECTO.CANAL,
      [CABECERAS_WEBBFF_ENUM.NOMBRES.ID_SESSION]: crypto.randomUUID()
    });

    if (token) {
      headers = headers.append('Authorization', `Bearer ${token}`);
    }

    return { headers };
  }

  /**
   * @description
   * Genera las cabeceras para endpoints públicos que no requieren autorización Bearer.
   * Usar en peticiones pre-login (imagen de usuario, estado de migración).
   * @return {{ headers: HttpHeaders }} Retorna las cabeceras base sin token.
   */
  private getPublicHeaders(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      [CABECERAS_WEBBFF_ENUM.NOMBRES.CANAL]: CABECERAS_WEBBFF_ENUM.VALORES_DEFECTO.CANAL,
      [CABECERAS_WEBBFF_ENUM.NOMBRES.ID_SESSION]: crypto.randomUUID()
    });
    return { headers };
  }

  consultarUsuarioImagen(nombreUsuario: string): Observable<RespuestaDtoEntity<ImagenUsuarioModeloEntity>> {
    const relativeUrl = WEBBFF_AUTENTICACION_ENUM.URL_IMAGEN_USUARIO.replace('{0}', encodeURIComponent(nombreUsuario));
    const url = relativeUrl;
    return this.rawHttp.get<RespuestaDtoEntity<ImagenUsuarioModeloEntity>>(url, this.getPublicHeaders());
  }

  consultarEstadoMigracionCash(usuario: string): Observable<RespuestaDtoEntity<UsuarioMigracionModeloEntity>> {
    const relativeUrl = WEBBFF_AUTENTICACION_ENUM.URL_ESTADO_MIGRACION_CASH.replace('{0}', encodeURIComponent(usuario));
    const url = relativeUrl;
    return this.rawHttp.get<RespuestaDtoEntity<UsuarioMigracionModeloEntity>>(url, this.getPublicHeaders());
  }

  /**
   * @description
   * Mantiene compatibilidad con la interfaz.
   * El factor de seguridad se obtiene directamente del LoginStateService tras el login.
   */
  consultarEstadoDobleFactor(): Observable<RespuestaDtoEntity<EstadoSegundoFactorModeloEntity>> {
    return new Observable(observer => {
      observer.next({ esExitoso: false, data: null } as any);
      observer.complete();
    });
  }

  /**
   * @description
   * Solicita la generación del código OTP para el factor indicado.
   * El backend envía el código al correo/celular del usuario.
   * Usa withCredentials para enviar la cookie de sesión creada en el /login.
   * @param factorSeguridad {number} Factor UI: 3=correo, 20=celular.
   */
  solicitarCodigoDobleFactor(factorSeguridad: number): Observable<RespuestaDtoEntity<any>> {
    let url = `Autenticacion/FactoresSeguridad/3`;
    if (factorSeguridad === 20) {
      url = `Autenticacion/FactoresSeguridad/Generico/3`;
    } else if (factorSeguridad === 10) {
      url = `Autenticacion/FactoresSeguridad/10`;
    } else if (factorSeguridad === 1) {
      url = `Autenticacion/FactoresSeguridad/1`;
    }

    return this.rawHttp.get<any>(url, {
      ...this.getHeaders(),
      withCredentials: true
    }).pipe(
      map(res => {
        const isSuccess = res.EsExitoso !== undefined ? res.EsExitoso : (res.HuboError === false);
        return {
          ...res,
          esExitoso: isSuccess,
          data: res.Datos || res.ObjetoRetorno,
          mensaje: res.Mensaje || res.MensajeRespuesta
        };
      }),
      catchError(err => {
        const msg = err?.error?.Mensaje || err?.message || 'No se pudo enviar el código OTP.';
        return of({ esExitoso: false, data: null, mensaje: msg } as any);
      })
    );
  }

  /**
   * @description
   * Valida el código OTP o Entrust enviado por el usuario para el factor indicado.
   * Envía los headers Segundo-Factor y Tipo-Segundo-Factor requeridos por el backend.
   * Usa withCredentials para enviar la cookie de sesión creada en el /login.
   * @param factorSeguridad {number} Factor UI (3 para OTP Email, 20 para OTP SMS, 10 para Entrust).
   * @param codigo {string} Código ingresado por el usuario.
   */
  validarCodigoDobleFactor(factorSeguridad: number, codigo: string): Observable<RespuestaDtoEntity<any>> {
    let factorBackend = 3;
    let tipoSegundoFactor = 'OTP';

    if (factorSeguridad === 10) {
      factorBackend = 10;
      tipoSegundoFactor = 'ENTRUST';
    } else if (factorSeguridad === 1) {
      factorBackend = 1;
      tipoSegundoFactor = 'TARJETA_COORDENADAS';
    }

    const url = `Autenticacion/FactoresSeguridad/${factorBackend}`;

    const headers = this.getHeaders().headers
      .append('Segundo-Factor', codigo)
      .append('Tipo-Segundo-Factor', tipoSegundoFactor);

    return this.rawHttp.post<any>(url, {}, {
      headers,
      withCredentials: true
    }).pipe(
      map(res => {
        const isSuccess = res.EsExitoso !== undefined ? res.EsExitoso : (res.HuboError === false);
        return {
          ...res,
          esExitoso: isSuccess,
          data: res.Datos || res.ObjetoRetorno,
          mensaje: res.Mensaje || res.MensajeRespuesta
        };
      }),
      catchError(err => {
        const msg = err?.error?.Mensaje || err?.message || 'Código incorrecto. Por favor, intente nuevamente.';
        return of({ esExitoso: false, data: null, mensaje: msg } as any);
      })
    );
  }


  /**
   * @description
   * Consulta los datos de contacto del usuario autenticado.
   * @return {Observable<any>} Retorna objeto con datos de respuesta del proceso.
   */
  consultarDatosContacto(): Observable<any> {
    const url = `Autenticacion/Usuarios/DatosContacto`;
    return this.rawHttp.get<any>(url, {
      ...this.getHeaders(),
      withCredentials: true
    }).pipe(
      map(res => {
        const datos = res.Datos || res.ObjetoRetorno || {};
        const datosContacto = datos.DatosContacto || {};
        
        const correo = datosContacto.Correo || {};
        const celular = datosContacto.Celular || {};

        return {
          esExitoso: res.EsExitoso ?? false,
          correoEnmascarado: correo.DireccionEnmascarada || '',
          celularEnmascarado: celular.NumeroEnmascarado || ''
        };
      }),
      catchError(() => of({ esExitoso: false, correoEnmascarado: '', celularEnmascarado: '' }))
    );
  }
}
