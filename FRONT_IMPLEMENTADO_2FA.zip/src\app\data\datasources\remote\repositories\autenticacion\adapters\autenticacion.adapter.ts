import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { IAutenticacionAdapter } from './iautenticacion.adapter';
import {
  AutenticacionUsuarioEntity
} from '../entities/autenticacion-usuario.entity';

@Injectable({ providedIn: 'root' })
export class AutenticacionAdapter implements IAutenticacionAdapter {
  constructor(private readonly httpClient: HttpClient) {}

  /**
   * @description
   * Realiza el proceso de autenticacion del usuario contra el endpoint de identidad.
   * @param username {string} Nombre del usuario.
   * @param password {string} Clave del usuario.
   * @return {Observable<AutenticacionUsuarioEntity>} Retorna la respuesta del proceso de login.
   */
  public login(username: string, password: string): Observable<AutenticacionUsuarioEntity> {
    const returnUrl = new URLSearchParams(window.location.search).get('returnUrl') ?? '';
    const body = new HttpParams()
      .set('username', username)
      .set('password', password)
      .set('returnUrl', returnUrl);

    const headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    return this.httpClient.post<AutenticacionUsuarioEntity>(
      'login',
      body,
      { headers }
    );
  }

}
