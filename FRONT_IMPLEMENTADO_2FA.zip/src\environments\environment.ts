export const environment = {
  production: true,
  autenticacionStandalone: false,
  host: {
    port: 'HOST_PORT'
  },
  apiUrl: '/apidemo',
  rutaCashManagement: 'https://cashmanagement.produbanco.com/cashmanagement/index.html',
  canal: 'IN'
};
