import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ingresoUsuarioGuard } from '../../shared/guards/ingreso-usuario.guard';

const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./auth-layout/auth-layout.component').then(m => m.AuthLayoutComponent),
    children: [
      {
        path: '',
        redirectTo: 'ingreso-usuario',
        pathMatch: 'full'
      },
      {
        path: 'ingreso-usuario',
        loadComponent: () =>
          import('./ingreso-usuario/ingreso-usuario.component').then(
            m => m.IngresoUsuarioComponent
          )
      },
      {
        path: 'ingreso-clave',
        loadComponent: () =>
          import('./ingreso-clave/ingreso-clave.component').then(
            m => m.IngresoClaveComponent
          ),
        canActivate: [ingresoUsuarioGuard]
      },
    ]
  },
  {
    path: 'segundo-factor',
    loadComponent: () =>
      import('./segundo-factor/segundo-factor.component').then(
        m => m.SegundoFactorComponent
      )
  }
];

/**
 * @description
 * Módulo de autenticación expuesto por Module Federation.
 * Este módulo agrupa las rutas de los componentes standalone del flujo de login.
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthenticationModule {}
