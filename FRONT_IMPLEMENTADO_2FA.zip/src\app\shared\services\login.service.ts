import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { IWebBffAutenticacionAdapter } from 'src/app/data/datasources/remote/repositories/autenticacion/adapters/iwebbff-autenticacion.adapter';
import {
  UsuarioImagenWebBffMapper,
  MigracionUsuarioWebBffMapper
} from 'src/app/data/datasources/remote/repositories/autenticacion/mappers/webbff-autenticacion-repository.mapper';
import { UsuarioImagenModel } from 'src/app/domain/models/usuario-imagen.model';
import { MigracionUsuarioModel } from 'src/app/domain/models/migracion-usuario.model';

/**
 * @description
 * Interface para la respuesta de validación de usuario.
 * Contiene la imagen de seguridad asociada al usuario autenticado.
 */
export interface ValidateUserResponse {
  securityImageBase64?: string;
}

/**
 * @description
 * Servicio encargado de gestionar las operaciones de autenticación
 * y consumo de servicios relacionados con el proceso de inicio de sesión.
 */
@Injectable({ providedIn: 'root' })
export class LoginService {
  private readonly imagenMapper = new UsuarioImagenWebBffMapper();
  private readonly migracionMapper = new MigracionUsuarioWebBffMapper();

  constructor(
    private readonly http: HttpClient,
    private readonly webBffAutenticacionAdapter: IWebBffAutenticacionAdapter
  ) {}

  /**
   * @description
   * Valida la existencia del usuario y consulta su imagen de seguridad.
   * @param username {string} Nombre del usuario a validar.
   * @return {Observable<ValidateUserResponse>} Retorna la imagen de seguridad asociada al usuario.
   */
  validateUser(username: string): Observable<ValidateUserResponse> {
    const url = new URL(
      `login/validar-usuario-imagen?username=${encodeURIComponent(username)}`,
      document.baseURI
    ).toString();

    return this.http.get<{ securityImageBase64?: string }>(url).pipe(
      map(
        res =>
          ({
            securityImageBase64: res?.securityImageBase64
          }) as ValidateUserResponse
      )
    );
  }

  /**
   * @description
   * Consulta la imagen de seguridad del usuario desde WebBFF.Produnet.
   * @param nombreUsuario {string} Nombre del usuario a consultar.
   * @return {Observable<UsuarioImagenModel>} Retorna modelo con imagen Base64.
   */
  consultarImagenUsuario(nombreUsuario: string): Observable<UsuarioImagenModel> {
    return this.webBffAutenticacionAdapter
      .consultarUsuarioImagen(nombreUsuario)
      .pipe(map(entity => this.imagenMapper.mapFrom(entity)));
  }

  /**
   * @description
   * Consulta el estado de migración Cash del usuario desde WebBFF.Produnet.
   * @param usuario {string} Nombre del usuario a consultar.
   * @return {Observable<MigracionUsuarioModel>} Retorna modelo con estado de migración.
   */
  consultarEstadoMigracionCash(usuario: string): Observable<MigracionUsuarioModel> {
    return this.webBffAutenticacionAdapter
      .consultarEstadoMigracionCash(usuario)
      .pipe(map(entity => this.migracionMapper.mapFrom(entity)));
  }

  /**
   * @description
   * Realiza el envío de credenciales al servicio de autenticación
   * mediante un formulario HTTP POST tradicional.
   * @param username {string} Nombre del usuario.
   * @param password {string} Clave del usuario.
   * @param returnUrl {string} URL de retorno posterior a la autenticación.
   */
  submitLogin(username: string, password: string, returnUrl?: string): void {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = new URL('login', document.baseURI).toString();
    form.enctype = 'application/x-www-form-urlencoded';
    form.style.display = 'none';

    const add = (name: string, value: string) => {
      const input = document.createElement('input');
      input.type = 'hidden';
      input.name = name;
      input.value = value;
      form.appendChild(input);
    };

    add('username', username);
    add('password', password);
    add('returnUrl', returnUrl ?? '');

    document.body.appendChild(form);
    form.submit();
  }
}