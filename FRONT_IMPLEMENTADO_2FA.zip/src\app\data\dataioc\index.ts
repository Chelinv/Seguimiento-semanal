﻿export { DATA_IOC } from './data.ioc';
export { AUTENTICACION_IOC } from './autenticacion.ioc';
