
USE [pr_autenticacion]
GO
 
DECLARE @RC int
DECLARE @i_ip varchar(15)='172.10.220.251'
DECLARE @i_machine_secret varchar(500)='/fr9HrgQvWFXheynyEuQqXrEqeNsfT4FPaDWaxMGm/H4m/J3D44lMbWKxDZMUOobBkawvBJoTPP0CwbkUD5HQ0reN4i2elaRWbhPLPjJtNzB+gc4+WHXPpWZEe5Cl2QllKNrjtTOPNpEYAHsD5k/bkA50nQl9krSTz9/eHstv+3Vyq4GsbPj7R5bAgxmljsw'
 
-- TODO: Set parameter values here.
 
EXECUTE @RC = [dbo].[spi_machine_secret] 
   @i_ip
  ,@i_machine_secret

SET @i_ip ='192.168.100.231'
-- TODO: Set parameter values here.
 
EXECUTE @RC = [dbo].[spi_machine_secret] 
   @i_ip
  ,@i_machine_secret

SET @i_ip ='172.28.208.1'

-- TODO: Set parameter values here.
 
EXECUTE @RC = [dbo].[spi_machine_secret] 
   @i_ip
  ,@i_machine_secret