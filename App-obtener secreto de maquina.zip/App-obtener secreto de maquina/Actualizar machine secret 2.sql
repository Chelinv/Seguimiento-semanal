USE [pr_autenticacion]
GO

--delete
--dbo.au_aplicacion_servidor 
--where as_ip_servidor in (
--'172.10.220.221'
--,'10.3.220.42'
--,'10.3.216.65'
--,'10.3.216.84'
--,'10.3.218.244'
--,'172.10.220.154'
--)

--select top 100 * from
--dbo.au_aplicacion nolock
--where ap_id_aplicacion in (2,3,4,17,25,35,37,42,43)

--172.10.220.186
--172.10.220.227
--10.3.219.106
--172.10.220.162
--10.3.216.34
--10.3.219.73
--172.10.221.32
--10.3.217.166
--172.10.221.42
--10.3.220.49
--172.10.220.226
--10.3.220.122
--172.10.220.216
--172.10.220.233
--172.10.220.212
--10.3.219.41
--10.3.218.92
--172.10.220.222
--10.3.218.92
--10.3.218.81
--172.10.220.196
--172.10.220.154
--10.3.218.46
--172.10.220.124
--172.10.220.127

DECLARE @RC int
DECLARE @i_ip varchar(15)='172.10.220.127'
DECLARE @i_machine_secret varchar(500)=
'/fr9HrgQvWFv3zZKCzmd0XyZH/3RVW6+AK+07VZMQzwlLpWzF4R0f789518J0E9iCRnUUKPERrrBask0gnqqs35EauGhKb5MuE4KJfsbtToCXxVFrhfYAAWPJ2GZVYu5xbLWpCMWGVEr6npVb/6KhmVlzB5sQIqOWJlCzTGOo7I='

-- TODO: Set parameter values here.

EXECUTE @RC = [dbo].[spi_machine_secret] 
   @i_ip
  ,@i_machine_secret

update pr_autenticacion..au_aplicacion_servidor
set as_machine_secret = @i_machine_secret
where as_ip_servidor in (@i_ip)

select * from pr_autenticacion..au_aplicacion_servidor
where as_ip_servidor = @i_ip

GO